package help;

import index.ConfigParse;
import index.PoiIndex;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import log.DataDecodeLog;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.wltea.analyzer.lucene.IKAnalyzer;

import singleAnalyzer.SingleAnalyzer;

import com.tianditu.search.config.DataIndex;
import com.tianditu.search.config.IndexParse;
import com.tianditu.search.config.IndexTable;

//import singleAnalyzer.SingleAnalyzer;

public class HelpSearch {
	public Map<String, String> codeMap = new HashMap<String, String>();
	ConfigParse config = new ConfigParse();

	public void loadCode(String fileName) {
		try {
			System.out.println("loadcode" + fileName);
			File file = new File(fileName);
			FileInputStream fi = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fi, "GBK");// ,
			// "utf-8" "gbk"
			BufferedReader reader = new BufferedReader(isr);

			String tempString = null;
			int count = 0;

			while ((tempString = reader.readLine()) != null) {

				// System.out.println(tempString);

				if (tempString != null) {

					count++;
					String[] arr = tempString.split(",");
					int num = arr.length;
					// System.out.print(arr.length);
					arr[0] = arr[0].replace("\"", "");
					arr[num - 1] = arr[num - 1].replace("\"", "");
					arr[num - 2] = arr[num - 2].replace("\"", "");
					arr[1] = arr[1].replace("\"", "");
					//如果是国外的编码，只放国家名称
					if (!arr[0].startsWith("156")) {
						codeMap.put(arr[0], arr[num - 3]);
					} else if (arr[num - 2].equals(arr[num - 1])
							&& arr[num - 2].equals(arr[1])) {

						codeMap.put(arr[0], arr[num - 1]);
					}
					if ("".equals(arr[num - 1]) && arr[num - 2].equals(arr[1])) {

						codeMap.put(arr[0], arr[num - 2]);
					} else if (arr[num - 1].equals(arr[1])) {

						codeMap.put(arr[0], arr[num - 2] + arr[1]);
					}

					else if (arr[num - 2].equals(arr[num - 1])) {
						codeMap.put(arr[0], arr[num - 2] + arr[1]);
					} else {
						codeMap.put(arr[0], arr[num - 2] + arr[num - 1]
								+ arr[1]);
					}
				}

			}
			System.out.println(codeMap.get("156110000"));
			System.out.println(codeMap.get("156810000"));
			System.out.println(codeMap.get("1001000027"));
			System.out.println("含有数据数量: " + codeMap.size());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {

		ArrayList<String> fileList = new ArrayList<String>();

		PoiIndex poi_index = new PoiIndex();
		HelpSearch index = new HelpSearch();

		try {

			ConfigParse config = new ConfigParse();
			config.ParseConfig(args[0]);
			if (!DataDecodeLog.IsInit())
				DataDecodeLog.initLog(config.SearchLog);
			index.config = config;
			index.loadCode(config.m_CodeName);

			IndexParse parse = new IndexParse();
			poi_index.engine_version = config.engine_version;
			poi_index.search_version = config.search_version;
			String xmlFile = config.HelpXMLFile;
			if (args.length >= 2) {
				xmlFile = args[1];
			}
			HashMap<String, DataIndex> indexs_mo = parse.getIndexTable(xmlFile);
			DataDecodeLog.logger.info("提示词开始编译");
			for (DataIndex t : indexs_mo.values()) {
				String outindex = config.IndexPath + t.getIndex_name();
				File indexDir = new File(outindex);
				// IKAnalyzer analyzer = new IKAnalyzer();
				Analyzer analyzer = null;
				if (t.analyzer == null) {
					analyzer = new IKAnalyzer();
				} else if (t.analyzer.equalsIgnoreCase("IKAnalyzer")) {
					analyzer = new IKAnalyzer();
				} else if (t.analyzer.equalsIgnoreCase("SingleAnalyzer")) {
					analyzer = new SingleAnalyzer();
				} else {
					analyzer = new StandardAnalyzer(Version.LUCENE_31);
				}
				@SuppressWarnings("deprecation")
				IndexWriter writer = new IndexWriter(
						FSDirectory.open(indexDir), analyzer, true,
						IndexWriter.MaxFieldLength.LIMITED);
				writer.setRAMBufferSizeMB(256);
				writer.setMaxMergeDocs(300000);
				writer.setMergeFactor(300000);
								
				

				// 增加元数据1
				for (IndexTable indext : t.getSource()) {
					if (indext.source_suffix != null&&!indext.source_suffix.equalsIgnoreCase("")) {
						String[] start_end = indext.source_suffix.split(",");
						int start = Integer.parseInt(start_end[0]);
						int end = Integer.parseInt(start_end[1]);
						for (int i = start; i <= end; i++) {
							String file_name = indext.source_path + i;
							//index.makeTextIndexByConfig(file_name, writer,
								//	indext, null);
							poi_index.makeTextIndexForPrompt(file_name,
									writer, indext, index);
						}
					} else {

						//index.makeTextIndexByConfig(indext.source_path, writer,
							//	indext, null);
						poi_index.makeTextIndexForPrompt(indext.source_path,
								writer, indext, index);
					}
					
					
					//poi_index.makeTextIndexForPrompt(indext.source_path,
						//	writer, indext, index);
				}
				
				

				writer.optimize();
				writer.close();
			}
			DataDecodeLog.logger.info("提示词结束编译");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return;

	}

}
