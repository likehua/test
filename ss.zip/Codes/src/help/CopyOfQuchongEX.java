package help;

import index.ConfigParse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.apache.lucene.document.Document;

import Util.AdminDataMan;
import Util.TypeDataMan;

public class CopyOfQuchongEX {

	public static Map<String, String> m_idList = new HashMap<String, String>();

	public static Map<String, String> codeMap = new HashMap<String, String>();

	public static HashSet<Integer> id_set = new HashSet<Integer>();
	
	public static HashMap<Integer, FileOutputStream> outstream_map = new HashMap<Integer, FileOutputStream>();
	public static HashMap<Integer, Writer> writer_map = new HashMap<Integer, Writer>();
	
	

	/**
	 * 关闭打开的文件和流
	 * 
	 * @return
	 */
	public static boolean CloseOutAndWriter() {

		for (Writer writer : writer_map.values()) {
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("close--------");
			}
		}

		for (FileOutputStream file_out : outstream_map.values()) {
			try {
				file_out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return false;

	}
	
	
	public static void loadCode(String fileName) {
		try {
			File file = new File(fileName);
			FileInputStream fi = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fi, "gbk");// ,
			// "utf-8"
			BufferedReader reader = new BufferedReader(isr);

			String tempString = null;
			int count = 0;

			while ((tempString = reader.readLine()) != null) {

				// System.out.println(tempString);

				if (tempString != null) {

					count++;
					String[] arr = tempString.split(",");
					int num = arr.length;
					// System.out.print(arr.length);
					codeMap.put(arr[0], arr[num - 1]);
					System.out.println(arr[0] + "  " + arr[num - 1] + "  "
							+ count);
				}

			}
			System.out.println("含有数据数量: " + codeMap.size());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final String configPath = "c:\\poi\\config.txt";
		Date da = new Date();

		System.out.println(da.toString());
		TypeDataMan man = new TypeDataMan();
		ConfigParse config = new ConfigParse();
		config.ParseConfig(args[0]);
		int count = 0;
		AdminDataMan admin = new AdminDataMan();
		System.out.println(config.m_HelpCode);
		admin.OpenAdminDataMan(config.m_HelpCode);

		String strList = new String();

		DBClenectEX Db = new DBClenectEX();
		// Db.loadClass("E:\\天地图类型代码.csv");
		// Db.loadCode("D:\\标准地名地址.csv");
		System.out.println(config.m_Location);
		// Db.loadCode("E:/data/sansha.txt");
		Db.loadCode(config.m_Location);
		String pinyinSql = config.m_pinyinSql;
		if(pinyinSql==null||pinyinSql.equals("")){
			pinyinSql="SELECT * FROM POIBASEINFO where auditingstate = 0 ";
		}
		long id = 0;

		try {

			Class.forName(config.DRIVER_CLASS);
			System.out.println("aaa1");
			FileOutputStream fos = new FileOutputStream(config.m_HelpSource,
					true);
			Writer out = new OutputStreamWriter(fos, "UTF-8");
			// Iterator iter2 = Db.codeMap.keySet().iterator();

			// while(iter2.hasNext()){

			// String Cityword =(String) iter2.next();
			// Connection conn = DriverManager.getConnection(
			// "jdbc:oracle:thin:@localhost:1521:ORCL", "poi", "123456");
			Connection conn = DriverManager.getConnection(config.JDBC_URL,config.JDBC_USER,config.JDBC_PASSWORD);
			// "jdbc:oracle:thin:@192.168.1.180:1521:TIANDITU180",
			// "tianditupoi", "tianditupoibak");
			// System.out.println("aaa12");
			Statement stmt = conn.createStatement();
			// System.out.println("aaa11");
			ResultSet rs = stmt
					.executeQuery(pinyinSql);// where
			System.out.println(pinyinSql);
			// nid
			// >
			// 10007551506
			// System.out.println("aaa");
			int num = 0;
			while (rs.next()) {
				Document doc = new Document();

				id = rs.getLong(1);
				String sid = id + "";
				//System.out.println(sid);
				if (sid.startsWith("2000")) {
					continue;
				}
				
				if(sid.equalsIgnoreCase("1018371313")){
					System.out.println("****************************");
					System.out.println("1018371313");
					System.out.println("****************************");
				}
				

				String name = rs.getString(2);
				String pinyin = rs.getString(3);

				if (pinyin == null) {
					//pinyin = "";
					//System.out.println("null"+name);
					pinyin = Pinyin.getPinYin(name);
				}
				pinyin = pinyin.replace(" ", "");
				String type = rs.getString(15);
				String citycode = rs.getString(48);
				String eng_name = rs.getNString(8);

				if (Db.codeMap.containsKey(citycode)) {
					num++;
					//System.out.println(num);
					// CopyOfQuchong.m_idList.put(name + "####" + citycode, id +
					// "####"+pinyin+"####"+type);
					String set_id = name + "####" + citycode;
					int int_id = set_id.hashCode();
					if (!id_set.contains(int_id)) {
						String lines = name + "####" + citycode + "####" + id
								+ "####" + pinyin + "####" + type + "\n";
						
						out = writer_map.get(pinyin.length());
						if (out == null) {
							fos = new FileOutputStream(config.m_HelpSource
									+ pinyin.length());
							//System.out.println("openfilename:"+config.m_HelpSource
								//	+ pinyin.length());
							outstream_map.put(pinyin.length(), fos);
							out = new OutputStreamWriter(fos, "UTF-8");
							writer_map.put(pinyin.length(), out);
						}
						
						if(sid.equalsIgnoreCase("1018371313")){
							System.out.println("****************************");
							System.out.println("1018371313: in file "+config.m_HelpSource
									+ pinyin.length());
							System.out.println("****************************");
							System.out.println(lines);
						}
						
						out.write(lines);
						id_set.add(int_id);
					}
					if (eng_name != null && !eng_name.equalsIgnoreCase("null")&&citycode.startsWith("99")) {
						String eng_set_id = eng_name + "####" + citycode;
						int eng_int_id = eng_set_id.hashCode();
						if (!id_set.contains(eng_int_id)) {
							String eng_lines = eng_name + "####" + citycode
									+ "####" + id + "####" + eng_name + "####"
									+ type + "\n";
							out = writer_map.get(pinyin.length());
							if (out == null) {
								fos = new FileOutputStream(config.m_HelpSource
										+ pinyin.length());
								//System.out.println("openfilename:"+config.m_HelpSource
									//	+ pinyin.length());
								outstream_map.put(pinyin.length(), fos);
								out = new OutputStreamWriter(fos, "UTF-8");
								writer_map.put(pinyin.length(), out);
							}

							out.write(eng_lines);
							id_set.add(eng_int_id);
						}
					}
					// String lines = name + "####" + citycode+"####"+id +
					// "####"+pinyin+"####"+type+"\n";
					// out.write(lines);
					// 将写入文件放到该处

				}

			}

			// System.out.println(CopyOfQuchong.m_idList.size() + "  " + num);

			// Iterator iter = CopyOfQuchong.m_idList.keySet().iterator();
			// FileWriter fw = new FileWriter("C:/helpdata0308" +
			// ".txt",true);
			// FileOutputStream fos = new
			// FileOutputStream("E:/data/sanshahelp.txt",true);
			// FileOutputStream fos = new
			// FileOutputStream(config.m_HelpSource,true);
			// Writer out = new OutputStreamWriter(fos, "UTF-8");
			// FileWriter fw = new FileWriter(config.m_HelpSource,false);

			// while (iter.hasNext()) {
			//
			// String key = (String) iter.next();
			// String result = key;
			// key += "####";
			// key += (String) CopyOfQuchong.m_idList.get(result);
			// System.out.println(Quchong.m_idList.get(key));
			// key += "\n";
			// fw.write(key);
			// out.write(key);

			// }
			// Thread.sleep(10);
			// CopyOfQuchong.m_idList.clear();
			// fw.close();
			conn.close();
			//out.close();
			//fos.close();
			// 关闭id_set
			id_set.clear();
			CloseOutAndWriter();
			da = new Date();
			System.out.println("finish:" + da.toString());

			// }
		} catch (Exception err) {
			System.out.println(strList);
			System.out.println(count + "  " + id);
			System.out.println(err.toString());
		}
	}

}
