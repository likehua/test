package help;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

import Util.AdminDataMan;
import Util.TypeDataMan;

public class DBClenect {
	
	
	Map<String, String> codeMap = new HashMap<String, String>();
	Map<String, String> typeMap = new HashMap<String, String>();

	public void loadCode(String fileName) {
		try {
			File file = new File(fileName);
			FileInputStream fi = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fi, "utf-8");// ,
																		// "utf-8"  "gbk"
			BufferedReader reader = new BufferedReader(isr);

			String tempString = null;
			int count = 0;

			while ((tempString = reader.readLine()) != null) {

				// System.out.println(tempString);

				if (tempString != null) {
					
					count++;
					String[] arr = tempString.split(",");
					int num = arr.length;
					//System.out.print(arr.length);
					arr[0] =arr[0].replace("\"","");
					arr[1] =arr[1].replace("\"","");
					codeMap.put(arr[0], arr[1]);
//					System.out.println(arr[0]+"  "+arr[6]);
//					codeMap.put(arr[1], arr[5]);
//					System.out.println(arr[1]+"  "+arr[5]);
//					codeMap.put(arr[2], arr[4]);
//					System.out.println(arr[2]+"  "+arr[4]);
//					codeMap.put(arr[0], arr[num-1]);
//					System.out.println(arr[0]+"  "+arr[num-1]+ "  "+count);
				}

			}
			System.out.println("含有数据数量: "+codeMap.size());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public String TrimZero(String word)
	{
		String result = null;
		
		if(word.endsWith("0000"))
			result = word.substring(0,2);
		else if(word.endsWith("00"))
			result = word.substring(0,4);
		else
			result = word;
			
		return result;
	}
	
	public void loadClass(String fileName) {
		try {
			File file = new File(fileName);
			FileInputStream fi = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fi, "utf-8");// ,
																		// "utf-8"
			BufferedReader reader = new BufferedReader(isr);

			String tempString = null;
			int count = 0;

			while ((tempString = reader.readLine()) != null) {

				//System.out.println(tempString);

				if (tempString != null) {
					
					count++;
					String[] arr = tempString.split(",");
					int num = arr.length;
					arr[0] = arr[0].replace("\"", "");
					arr[1] = arr[1].replace("\"", "");
					//System.out.print(arr.length);
					
					String key = TrimZero(arr[0]);
					System.out.println(key+ "  "+ arr[1]);
					typeMap.put(key, arr[1]);
					//System.out.println(arr[0]+"  "+arr[num-1]+ "  "+count);
				}

			}
			System.out.println("含有数据数量: "+codeMap.size());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void AccessDb() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:ORCL", "poi", "123456");
			// Statement state=conn.createStatement();
			// int
			// r=state.executeUpdate("insert into emp(EMPNO,ENAME) values('2222','handan')");
			// ResultSet rs= state.executeQuery("select * from emp");
			PreparedStatement state = conn
					.prepareStatement("select * from emp where ENAME=?");
			state.setString(1, "handan");
			ResultSet rs = state.executeQuery();

			while (rs.next()) {
				System.out.print(rs.getString(1) + "    ");
				System.out.print(rs.getString(2) + "    ");
				System.out.print(rs.getString(3) + "    ");
				System.out.print(rs.getString(4) + "    ");
				System.out.print(rs.getString(5) + "    ");
				System.out.print(rs.getString(6) + "    ");
				System.out.print(rs.getString(7) + "    ");
				System.out.println(rs.getString(8));
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	// public static void main(String []args)
	// {
	// AccessDb();
	// }

	public static void main(String[] args) throws Exception {
		TypeDataMan man = new TypeDataMan();
		int count = 0;
		AdminDataMan admin = new AdminDataMan();
		admin.OpenAdminDataMan("D:\\android_tmode\\Ard_TModeOnLineAAA\\MakeDBIndex\\data\\AdminCode.dat");
		
		DBClenect Db = new DBClenect(); 
		Db.loadClass("E:\\天地图类型代码.csv");
		Db.loadCode("E:\\标准地名地址.txt");
		
//		LayIndex index = new LayIndex();
//		DomParse dom = new DomParse();
//		index.list = dom.GetIndexname("D:\\demo.xml");
//		System.out.println(index.list.size());
//		index.InitIndex(index.list);
		String strList = new String();
		String key = null;
		
		
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("aaa1");
//			Connection conn = DriverManager.getConnection(
//					"jdbc:oracle:thin:@localhost:1521:ORCL", "poi", "123456");
			Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:TIANDITUMAP", "tianditupoi", "asdfasdf");
		//	System.out.println("aaa12");
			Statement stmt = conn.createStatement();
			System.out.println("aaa11");
			ResultSet rs = stmt.executeQuery("SELECT * FROM POIBASEINFO");// where nid >10007600247where nid >10007610247 // where nid >10007613245
			System.out.println("aaa");
			while (rs.next()) {
			
				
				count++;
//				if(count < 7613296)
//					continue;
				Document doc = new Document();
				long id = rs.getLong(1);
				String name = rs.getString(2);
				String pinyin = rs.getString(3);
				pinyin = pinyin.replace(" ", "");
				
				String citycode = rs.getString(14);
				String type = rs.getString(15);
				
				if(type.startsWith("1401"));
				{
					doc.setBoost(20.0f);
				}
				
				String sid = id+"";
				if(sid.startsWith("2000"))
				{
					continue;
				}
//				if(type.equals("140301"))
//				{
//					;
//				}
				
				

				//name = StringTool.CharStandardization(name);
				doc.add(new Field("name", name, Field.Store.YES,
						Field.Index.ANALYZED));
				if (pinyin.length() == 0) {
					pinyin = Pinyin.getPinYin(name);
				}
				pinyin = pinyin.toLowerCase(); 
				doc.add(new Field("pinyin", pinyin, Field.Store.YES,
						Field.Index.NOT_ANALYZED));

				//品组 城市编码
				String citytype = citycode;
				citytype += " ";
				citytype += citycode.substring(0,4);
				citytype +="00";
				citytype += " ";
				citytype += citycode.substring(0,2);
				citytype +="0000";
				
				doc.add(new Field("totalcity", citytype, Field.Store.YES,
						Field.Index.ANALYZED));
			
				String keyindex = citycode;
				
			//	System.out.println(citycode+"aaaaaaaaaaaaaaaaaaaaaaaaaa");
				 if(keyindex.length()>4)
	                {
					 keyindex = keyindex.substring(0, 4);
	             //   System.out.println(keyindex);
	                }
				//String key = index.list.get(keyindex);
				// key = index.list.get(keyindex);
				if(key == null )
				{
					count++;
					//System.out.print(arr[1]);
					//index.add(arr[1]);
					//System.out.println("*******************");
				}
//				System.out.println(index.ID_map.size()+"  map size is");
				
//				IndexWriter aaaa = index.ID_map.get(key);
//				if( aaaa == null)
//				{
//				System.out.println("index  is  empty!");
//				}
//				aaaa.addDocument(doc);
//				index.ID_map.get(key).addDocument(doc);
				
				//writer.addDocument(doc);
				//count++;
			if(count %100000 == 0 )
				
				System.out.println(count);

//
//															// GetSegCode(itmp);
//				System.out.println(itype);
//				// System.out.println(rs.s)
//				strList = id + " " + name + "  " + pinyin + "  "
//				+ address + " " + tel + "  " + citycode + "  " + type
//				+ " " + lon + " " + lat;
//				System.out.println(id + " " + name + "  " + pinyin + "  "
//						+ address + " " + tel + "  " + citycode + "  " + type
//						+ " " + lon + " " + lat);// + "  "+address
//				 System.out.println(rs.getInt(1) + "\t" + rs.getString(2)+
//				 "\t" +rs.getString(3));
			}
//			index.UnIndex();

		} catch (Exception err) {
			//System.out.println(
			//System.out.println(strList );
			System.out.println(count + "  " + key );
			err.printStackTrace();
		}
	}
}
