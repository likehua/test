package help;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

public class Pinyin {
	/**
	 * 将汉字转换为全拼
	 * 
	 * @param src
	 * @return String
	 */
	public static String getPinYin(String src) throws Exception {

		if (src.equals(null)) {
			String result = "";
			// strBuf.append("");
			return result;

		}
		char[] t1 = null;
		t1 = src.toCharArray();
		// System.out.println(t1.length);
		String[] t2 = new String[t1.length];
		// System.out.println(t2.length);
		// 设置汉字拼音输出的格式
		HanyuPinyinOutputFormat t3 = new HanyuPinyinOutputFormat();
		t3.setCaseType(HanyuPinyinCaseType.LOWERCASE);
		t3.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
		t3.setVCharType(HanyuPinyinVCharType.WITH_V);
		String t4 = "";
		int t0 = t1.length;
		try {
			for (int i = 0; i < t0; i++) {
				// 判断是否为汉字字符
				// System.out.println(t0);
				if (t1[i] == '堒') {
					t4 += "kun";
					continue;
				}
				else if (t1[i] == '湭') {
					t4 += "qiu";
					continue;
				}
				else if (t1[i] == '屷') {
					t4 += "hui";
					continue;
				}
				else if (t1[i] == '袥') {
					t4 += "tuo";
					continue;
				}
				else if (t1[i] == '迌') {
					t4 += "tu";
					continue;
				}
				else if (t1[i] == '辻') {
					t4 += "shí";
					continue;
				}
				else if (t1[i] == '胿') {
					t4 += "gui1";
					continue;
				}
				else if (t1[i] == '蓃') {
					t4 += "sǒu/sōu";
					continue;
				}
				else if (t1[i] == '虅') {
					t4 += "teng";
					continue;
				}
				else if (t1[i] == '哖') {
					t4 += "nian";
					continue;
				}
				else if (t1[i] == '垊') {
					t4 += "min";
					continue;
				}
				// /
				else if (t1[i] == '垈') {
					t4 += "dai";
					continue;
				}
				else if (t1[i] == '垳') {
					t4 += "hanɡ";
					continue;
				}
				else if (t1[i] == '圷') {
					t4 += "xia";
					continue;
				}
				else if (t1[i] == '冧') {
					t4 += "lin";
					continue;
				}
				else if (t1[i] == '倿') {
					t4 += "ning";
					continue;
				}
				else if (t1[i] == '麿') {
					t4 += "mi";
					continue;
				}
				else if (t1[i] == '嶶') {
					t4 += "wei";
					continue;
				}
				else if (t1[i] == '屷')// 会
				{
					t4 += "hui";
					continue;
				}
				else if (t1[i] == '岼') {
					t4 += "ping";
					continue;
				}
				else if (t1[i] == '鋢') {
					t4 += "lüe";
					continue;
				}
				else if (t1[i] == '庒') {
					t4 += "zhuang";
					continue;
				}
				else if (t1[i] == '夻') {
					t4 += "hua";
					continue;
				}
				//
				else if (t1[i] == '奍') {
					t4 += "quan"; ///juàn
					continue;
				}
				else if (t1[i] == '堏') {
					t4 += "fanɡ";
					continue;
				}
				else if (t1[i] == '塀') {
					t4 += "ping";
					continue;
				}
				else if (t1[i] == '墹') {
					t4 += "jian";
					continue;
				}

				else if (t1[i] == '闎') {
					t4 += "quan";
					continue;
				}
				else if (t1[i] == '嬜') {
					t4 += "xin";
					continue;
				}
				else if (t1[i] == '婲') {
					t4 += "hua";
					continue;
				}
				else if (t1[i] == '嫲') {
					t4 += "ma";
					continue;
				}
				else if (t1[i] == '柨') {
					t4 += "bu"; ///pū
					continue;
				}
				else if (t1[i] == '挧') {
					t4 += "yu";
					continue;
				}
				else if (t1[i] == '渏') {
					t4 += "yi";
					continue;
				}
				//
				else if (t1[i] == '湭') {
					t4 += "qiu";
					continue;
				}

				else if (t1[i] == '溋') {
					t4 += "ying";
					continue;
				}
				else if (t1[i] == '濸') {
					t4 += "canɡ";
					continue;
				}
				else if (t1[i] == '汢') {
					t4 += "tu"; ///tǔ
					continue;
				}
				else if (t1[i] == '汣') {
					t4 += "jiu";
					continue;
				}
				else if (t1[i] == '橸') {
					t4 += "jing";
					continue;
				}
				else if (t1[i] == '櫵') {
					t4 += "qiao";
					continue;
				}
				else if (t1[i] == '櫊') {
					t4 += "ɡe"; ///ge
					continue;
				}
				else if (t1[i] == '殝') {
					t4 += "zhen";
					continue;
				}

				else if (t1[i] == '栆') {
					t4 += "zao";
					continue;
				}
				else if (t1[i] == '栶') {
					t4 += "yin";
					continue;
				}
				else if (t1[i] == '椣') {
					t4 += "dian";
					continue;
				}
				else if (t1[i] == '槡') {
					t4 += "sang";
					continue;
				}
				else if (t1[i] == '琻') {
					t4 += "jin";
					continue;
				}
				else if (t1[i] == '琒') {
					t4 += "feng";
					continue;
				}
				else if (t1[i] == '爎') {
					t4 += "liao";//liǎo
					continue;
				}
				//
				else if (t1[i] == '焒') {
					t4 += "lv";
					continue;
				}
				else if (t1[i] == '灜') {
					t4 += "ying";
					continue;
				}
				else if (t1[i] == '罉') {
					t4 += "cheng";
					continue;
				}
				else if (t1[i] == '笹') {
					t4 += "ti";
					continue;
				}
				else if (t1[i] == '篐') {
					t4 += "gu";
					continue;
				}
				else if (t1[i] == '磗') {
					t4 += "zhuan";
					continue;
				}
				else if (t1[i] == '夑') {
					t4 += "xie";
					continue;
				}
				else if (t1[i] == '栃') {
					t4 += "li";
					continue;
				}
				else if (t1[i] == '叾') {
					t4 += "dug";
					continue;
				}
				else if (t1[i] == '勐') {
					t4 += "meng";
					continue;
				}
				else if (t1[i] == '屶') {
					t4 += "hui";
					continue;
				}
				else if (t1[i] == '橵') {
					t4 += "san";
					continue;
				}else if (t1[i] == '涥') {
					t4 += "heng";
					continue;
				}else if (t1[i] == '玛') {
					t4 += "ma";
					continue;
				}else if (t1[i] == '珯') {
					t4 += "lao";
					continue;
				}
				else if (t1[i] == '塘') {
					t4 += "tang";
					continue;
				}else if (t1[i] == '嵵') {
					t4 += "shi";
					continue;
				}else if (t1[i] == '裡') {
					t4 += "li";
					continue;
				}
				if (Character.toString(t1[i]).matches("[\\u4E00-\\u9FA5]+")) {
					t2 = PinyinHelper.toHanyuPinyinStringArray(t1[i], t3);// 将汉字的几种全拼都存到t2数组中
					/*
					 * if(t2[0].equals(null)) { t2[0] = ""; //
					 * strBuf.append(""); //return result;
					 * 
					 * }
					 */
					//liubao add process null point exception
					if (t2 == null || t2.length == 0)
						t2[0] = "";
					// System.out.println("length "+t2.length);
					for (int m = 0; m < 1; m++) {
						t4 += t2[m];// 取出该汉字全拼的第一种读音并连接到字符串t4后
						//if (m != t2.length - 1)
							//t4 += "/";
					}
					t4 += "";

				} else {
					// 如果不是汉字字符，直接取出字符并连接到字符串t4后
					t4 += Character.toString(t1[i]);
				}
			}
		} catch (BadHanyuPinyinOutputFormatCombination e) {
			// TODO Auto-generated catch block
			System.out.println(src);
			System.out.println(src);
			e.printStackTrace();
		}
		t4 = t4.trim();
		t4 += "";

		return t4;
	}

	/**
	 * 提取每个汉字的首字母
	 * 
	 * @param str
	 * @return String
	 */
	public static String getPinYinHeadChar(String str) {
		String convert = "";
		for (int j = 0; j < str.length(); j++) {
			char word = str.charAt(j);
			// 提取汉字的首字母
			String[] pinyinArray = PinyinHelper.toHanyuPinyinStringArray(word);
			if (pinyinArray != null) {
				convert += pinyinArray[0].charAt(0);
			} else {
				convert += word;
			}
		}
		return convert;
	}

	/**
	 * 将字符串转换成ASCII码
	 * 
	 * @param cnStr
	 * @return String
	 */
	public static String getCnASCII(String cnStr) {
		StringBuffer strBuf = new StringBuffer();

		if (cnStr.equals(null)) {
			strBuf.append("");
			return strBuf.toString();

		}

		// 将字符串转换成字节序列
		byte[] bGBK = cnStr.getBytes();
		for (int i = 0; i < bGBK.length; i++) {
			// System.out.println(Integer.toHexString(bGBK[i] & 0xff));
			// 将每个字符转换成ASCII码
			strBuf.append(Integer.toHexString(bGBK[i] & 0xff));
		}
		return strBuf.toString();
	}

	public static String getPinYinFirst(String src) {
		char[] t1 = null;
		t1 = src.toCharArray();
		// System.out.println(t1.length);
		String[] t2 = new String[t1.length];
		// System.out.println(t2.length);
		// 设置汉字拼音输出的格式
		HanyuPinyinOutputFormat t3 = new HanyuPinyinOutputFormat();
		t3.setCaseType(HanyuPinyinCaseType.LOWERCASE);
		t3.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
		t3.setVCharType(HanyuPinyinVCharType.WITH_V);
		// String t4 = "\"";
		String t4 = "";
		int t0 = t1.length;
		try {
			for (int i = 0; i < t0; i++) {
				// 判断是否为汉字字符
				// System.out.println(t1[i]);
				int num = 0;
				int same = 0;

//				// System.out.println(t0);
//				if (t1[i] == '堒') {
//					t4 += "kun";
//					continue;
//				}
//				if (t1[i] == '湭') {
//					t4 += "qiu";
//					continue;
//				}
//				if (t1[i] == '屷') {
//					t4 += "hui";
//					continue;
//				}
//				if (t1[i] == '袥') {
//					t4 += "tuo";
//					continue;
//				}
//				if (t1[i] == '迌') {
//					t4 += "tu";
//					continue;
//				}
//				if (t1[i] == '辻') {
//					t4 += "shí";
//					continue;
//				}
//				if (t1[i] == '胿') {
//					t4 += "gui1";
//					continue;
//				}
//				if (t1[i] == '蓃') {
//					t4 += "sǒu/sōu";
//					continue;
//				}
//				if (t1[i] == '虅') {
//					t4 += "téng";
//					continue;
//				}
//				if (t1[i] == '哖') {
//					t4 += "nián";
//					continue;
//				}
//				if (t1[i] == '垊') {
//					t4 += "min";
//					continue;
//				}
//				// /
//				if (t1[i] == '垈') {
//					t4 += "dài";
//					continue;
//				}
//				if (t1[i] == '垳') {
//					t4 += "hánɡ";
//					continue;
//				}
//				if (t1[i] == '圷') {
//					t4 += "xia";
//					continue;
//				}
//				if (t1[i] == '冧') {
//					t4 += "lín";
//					continue;
//				}
//				if (t1[i] == '倿') {
//					t4 += "nìng";
//					continue;
//				}
//				if (t1[i] == '麿') {
//					t4 += "mi";
//					continue;
//				}
//				if (t1[i] == '嶶') {
//					t4 += "wei";
//					continue;
//				}
//				if (t1[i] == '屷')// 会
//				{
//					t4 += "hui";
//					continue;
//				}
//				if (t1[i] == '岼') {
//					t4 += "ping";
//					continue;
//				}
//				if (t1[i] == '鋢') {
//					t4 += "lüè";
//					continue;
//				}
//				if (t1[i] == '庒') {
//					t4 += "zhuāng";
//					continue;
//				}
//				if (t1[i] == '夻') {
//					t4 += "huà";
//					continue;
//				}
//				//
//				if (t1[i] == '奍') {
//					t4 += "quān/juàn";
//					continue;
//				}
//				if (t1[i] == '堏') {
//					t4 += "fānɡ";
//					continue;
//				}
//				if (t1[i] == '塀') {
//					t4 += "píng";
//					continue;
//				}
//				if (t1[i] == '墹') {
//					t4 += "jiàn";
//					continue;
//				}
//
//				if (t1[i] == '闎') {
//					t4 += "quán";
//					continue;
//				}
//				if (t1[i] == '嬜') {
//					t4 += "xīn";
//					continue;
//				}
//				if (t1[i] == '婲') {
//					t4 += "huā";
//					continue;
//				}
//				if (t1[i] == '嫲') {
//					t4 += "mā/má";
//					continue;
//				}
//				if (t1[i] == '柨') {
//					t4 += "bù/pū";
//					continue;
//				}
//				if (t1[i] == '挧') {
//					t4 += "yǔ";
//					continue;
//				}
//				if (t1[i] == '渏') {
//					t4 += "yī";
//					continue;
//				}
//				//
//				if (t1[i] == '湭') {
//					t4 += "qiu";
//					continue;
//				}
//
//				if (t1[i] == '溋') {
//					t4 += "yíng";
//					continue;
//				}
//				if (t1[i] == '濸') {
//					t4 += "cānɡ";
//					continue;
//				}
//				if (t1[i] == '汢') {
//					t4 += "tu/tǔ";
//					continue;
//				}
//				if (t1[i] == '汣') {
//					t4 += "jiu";
//					continue;
//				}
//				if (t1[i] == '橸') {
//					t4 += "jing";
//					continue;
//				}
//				if (t1[i] == '櫵') {
//					t4 += "qiáo";
//					continue;
//				}
//				if (t1[i] == '櫊') {
//					t4 += "ɡé/ge";
//					continue;
//				}
//				if (t1[i] == '殝') {
//					t4 += "zhen";
//					continue;
//				}
//
//				if (t1[i] == '栆') {
//					t4 += "zao";
//					continue;
//				}
//				if (t1[i] == '栶') {
//					t4 += "yīn";
//					continue;
//				}
//				if (t1[i] == '椣') {
//					t4 += "diǎn";
//					continue;
//				}
//				if (t1[i] == '槡') {
//					t4 += "sang";
//					continue;
//				}
//				if (t1[i] == '琻') {
//					t4 += "jin";
//					continue;
//				}
//				if (t1[i] == '琒') {
//					t4 += "fēnɡ/feng";
//					continue;
//				}
//				if (t1[i] == '爎') {
//					t4 += "liáo/liǎo ";
//					continue;
//				}
//				//
//				if (t1[i] == '焒') {
//					t4 += "lǚ";
//					continue;
//				}
//				if (t1[i] == '灜') {
//					t4 += "yíng";
//					continue;
//				}
//				if (t1[i] == '罉') {
//					t4 += "chēng";
//					continue;
//				}
//				if (t1[i] == '笹') {
//					t4 += "tì";
//					continue;
//				}
//				if (t1[i] == '篐') {
//					t4 += "gū";
//					continue;
//				}
//				if (t1[i] == '磗') {
//					t4 += "zhuān";
//					continue;
//				}

				if (t1[i] == '堒') {
					t4 += "kun";
					continue;
				}
				else if (t1[i] == '湭') {
					t4 += "qiu";
					continue;
				}
				else if (t1[i] == '屷') {
					t4 += "hui";
					continue;
				}
				else if (t1[i] == '袥') {
					t4 += "tuo";
					continue;
				}
				else if (t1[i] == '迌') {
					t4 += "tu";
					continue;
				}
				else if (t1[i] == '辻') {
					t4 += "shí";
					continue;
				}
				else if (t1[i] == '胿') {
					t4 += "gui1";
					continue;
				}
				else if (t1[i] == '蓃') {
					t4 += "sǒu/sōu";
					continue;
				}
				else if (t1[i] == '虅') {
					t4 += "teng";
					continue;
				}
				else if (t1[i] == '哖') {
					t4 += "nian";
					continue;
				}
				else if (t1[i] == '垊') {
					t4 += "min";
					continue;
				}
				// /
				else if (t1[i] == '垈') {
					t4 += "dai";
					continue;
				}
				else if (t1[i] == '垳') {
					t4 += "hanɡ";
					continue;
				}
				else if (t1[i] == '圷') {
					t4 += "xia";
					continue;
				}
				else if (t1[i] == '冧') {
					t4 += "lin";
					continue;
				}
				else if (t1[i] == '倿') {
					t4 += "ning";
					continue;
				}
				else if (t1[i] == '麿') {
					t4 += "mi";
					continue;
				}
				else if (t1[i] == '嶶') {
					t4 += "wei";
					continue;
				}
				else if (t1[i] == '屷')// 会
				{
					t4 += "hui";
					continue;
				}
				else if (t1[i] == '岼') {
					t4 += "ping";
					continue;
				}
				else if (t1[i] == '鋢') {
					t4 += "lüe";
					continue;
				}
				else if (t1[i] == '庒') {
					t4 += "zhuang";
					continue;
				}
				else if (t1[i] == '夻') {
					t4 += "hua";
					continue;
				}
				//
				else if (t1[i] == '奍') {
					t4 += "quan"; ///juàn
					continue;
				}
				else if (t1[i] == '堏') {
					t4 += "fanɡ";
					continue;
				}
				else if (t1[i] == '塀') {
					t4 += "ping";
					continue;
				}
				else if (t1[i] == '墹') {
					t4 += "jian";
					continue;
				}

				else if (t1[i] == '闎') {
					t4 += "quan";
					continue;
				}
				else if (t1[i] == '嬜') {
					t4 += "xin";
					continue;
				}
				else if (t1[i] == '婲') {
					t4 += "hua";
					continue;
				}
				else if (t1[i] == '嫲') {
					t4 += "ma";
					continue;
				}
				else if (t1[i] == '柨') {
					t4 += "bu"; ///pū
					continue;
				}
				else if (t1[i] == '挧') {
					t4 += "yu";
					continue;
				}
				else if (t1[i] == '渏') {
					t4 += "yi";
					continue;
				}
				//
				else if (t1[i] == '湭') {
					t4 += "qiu";
					continue;
				}

				else if (t1[i] == '溋') {
					t4 += "ying";
					continue;
				}
				else if (t1[i] == '濸') {
					t4 += "canɡ";
					continue;
				}
				else if (t1[i] == '汢') {
					t4 += "tu"; ///tǔ
					continue;
				}
				else if (t1[i] == '汣') {
					t4 += "jiu";
					continue;
				}
				else if (t1[i] == '橸') {
					t4 += "jing";
					continue;
				}
				else if (t1[i] == '櫵') {
					t4 += "qiao";
					continue;
				}
				else if (t1[i] == '櫊') {
					t4 += "ɡe"; ///ge
					continue;
				}
				else if (t1[i] == '殝') {
					t4 += "zhen";
					continue;
				}

				else if (t1[i] == '栆') {
					t4 += "zao";
					continue;
				}
				else if (t1[i] == '栶') {
					t4 += "yin";
					continue;
				}
				else if (t1[i] == '椣') {
					t4 += "dian";
					continue;
				}
				else if (t1[i] == '槡') {
					t4 += "sang";
					continue;
				}
				else if (t1[i] == '琻') {
					t4 += "jin";
					continue;
				}
				else if (t1[i] == '琒') {
					t4 += "feng";
					continue;
				}
				else if (t1[i] == '爎') {
					t4 += "liao";//liǎo
					continue;
				}
				//
				else if (t1[i] == '焒') {
					t4 += "lv";
					continue;
				}
				else if (t1[i] == '灜') {
					t4 += "ying";
					continue;
				}
				else if (t1[i] == '罉') {
					t4 += "cheng";
					continue;
				}
				else if (t1[i] == '笹') {
					t4 += "ti";
					continue;
				}
				else if (t1[i] == '篐') {
					t4 += "gu";
					continue;
				}
				else if (t1[i] == '磗') {
					t4 += "zhuan";
					continue;
				}
				else if (t1[i] == '夑') {
					t4 += "xie";
					continue;
				}
				else if (t1[i] == '栃') {
					t4 += "li";
					continue;
				}
				else if (t1[i] == '叾') {
					t4 += "dug";
					continue;
				}
				else if (t1[i] == '勐') {
					t4 += "meng";
					continue;
				}
				else if (t1[i] == '屶') {
					t4 += "hui";
					continue;
				}
				else if (t1[i] == '橵') {
					t4 += "san";
					continue;
				}
				else if (t1[i] == '簯') {
					t4 += "qi";
					continue;
				}
				else if (t1[i] == '杣') {
					t4 += "mian";
					continue;
				}
				
				
				
				if (Character.toString(t1[i]).matches("[\\u4E00-\\u9FA5]+")) {
					t2 = PinyinHelper.toHanyuPinyinStringArray(t1[i], t3);// 将汉字的几种全拼都存到t2数组中
					// System.out.println(t2[0]);
					t4 += t2[0];// 取出该汉字全拼的第一种读音并连接到字符串t4后
					// if (t2.length == 1) {
					// t4 += t2[0];
					// } else {
					// // t4 += "# ";
					// for (int k = 0; k < t2.length; k++) {
					// boolean flag = false;
					// for (int t = 0; t <= k - 1; t++) {
					// if (t2[t].equals(t2[k])) {
					// same++;
					// flag = true;
					// break;
					// }
					//
					// }
					// num++;
					// if (!flag) {
					// t4 += t2[k];
					// // if (k != t2.length - 1 && num == 1 && num !=
					// // k) {
					// // t4 += "|";
					// // }
					// // System.out.println(same + "   " + num +
					// // " t2 length :" + t2.length);
					// // if(same +num > t2.length)
					// // {
					// // t4 += "";
					// // }
					// if (k != t2.length && num > 0) {
					// t4 += "|";
					// }
					// }
					//
					// // t4 += t2[k];
					// // t4 += "/";
					//
					// }
					// // t4 += "#";
					// }
					// // t4 += " ";
					// } else {
					// // 如果不是汉字字符，直接取出字符并连接到字符串t4后
					// t4 += Character.toString(t1[i]);
					// }
					//
					// if (t4.endsWith("|")) {
					// t4 = t4.substring(0, t4.length() - 1);
				}
			}
		} catch (Exception e) {
			System.out.println(src);
			e.printStackTrace();
		}

		// if (t4.endsWith("|")) {
		// t4 = t4.substring(0, t4.length() - 1);
		// }
		return t4;
	}
	
	public static void Translate(String filesrc, String fileSingle,
			String FileMulti) throws Exception {
		int num = 0;
		File file = new File(filesrc);
		FileInputStream fi = new FileInputStream(file);
		InputStreamReader isr = new InputStreamReader(fi, "gbk");// , "utf-8"
		BufferedReader reader = new BufferedReader(isr);
		String tempString = null;

		FileWriter aa = new FileWriter(fileSingle);
		FileWriter bb = new FileWriter(FileMulti);

		while ((tempString = reader.readLine()) != null) {

			num++;
			tempString = tempString.trim();
			String arr[] = tempString.split(",");
			arr[1] = arr[1].replace("\"", "");

			String pinyin = getPinYin(arr[1]);
			if (pinyin.indexOf("/") > 0) {
				bb.write(tempString);
				bb.write(",");
				bb.write(pinyin);
				bb.write("\n");
			} else {
				aa.write(tempString);
				aa.write(",");
				aa.write(pinyin);
				aa.write("\n");
			}
			if(num % 10000 ==0)
			{
				aa.flush();
				bb.flush();
			}

		}
		aa.close();
		bb.close();
		fi.close();
	}
 
	public static void main(String[] args) throws Exception {
		String cnStr = "杨杣埫";
		//System.out.println(getPinYin(cnStr));

		// Translate("D:/查询词.txt", "D:/chaxunci.txt");
		//Translate(args[0], args[1], args[2]);

		//System.out.println(Integer.MAX_VALUE);
		// System.out.println(getPinYinHeadChar(cnStr));
		// System.out.println(getCnASCII(cnStr));
	}

}