package log;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class DataDecodeLog {
	
	public static Logger logger = null ;
	
	protected static boolean bIsInit = false;
	
	public static void initLog(String strCfgPath){
		if(bIsInit)
			return;
		
		PropertyConfigurator.configure(strCfgPath);
		logger = Logger.getLogger("datadecode");
		bIsInit = true;
	}	
	
	public static boolean IsInit(){
		return bIsInit;
	}

}
