/**
 * IK 中文分词  版本 5.0
 * IK Analyzer release 5.0
 * 
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * 源代码由林良益(linliangyi2005@gmail.com)提供
 * 版权声明 2012，乌龙茶工作室
 * provided by Linliangyi and copyright 2012 by Oolong studio
 * 

 * 
 */
package org.wltea.analyzer.lucene;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;

import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;

import org.wltea.analyzer.core.IKSegmenter;
import org.wltea.analyzer.core.Lexeme;
import org.wltea.analyzer.dic.Dictionary;

/**
 * IK分词器 Lucene Tokenizer适配器类
 * 兼容Lucene 3.1以上版本
 */
public final class IKTokenizer extends Tokenizer {
	private static final int  FINE_ANALYSIS = 1; 	// 细粒度分词
	private static final int  SMART_ANALYSIS = 2; 	// 智能分词
	private static final int  ADD_ANALYSIS = 3;		// 补充分词
	
	//IK分词器实现
	private IKSegmenter _SmartIKImplement;
	private IKSegmenter _FineIKImplement;
	//词元文本属性
	private CharTermAttribute termAtt;
	//词元位移属性
	private OffsetAttribute offsetAtt;
	//记录最后一个词元的结束位置
	private int finalOffset;
	
	// 记录已经分出的词位置
	private HashSet<TermPos> setTermPosSet;
	// 分词步骤
	private int iProgress;
	// 记录Reader
	private StringReader inReader;
	// 记录补充停用词及返回的下标
	private int iAddIndex = -1;
	private ArrayList<Integer> listAddWord = null;
	private char[]  arrWord = null;
	private int     iWordLength = 0;
	/**
	 * Lucene 3.5 Tokenizer适配器类构造函数
	 * @param in
	 * @param useSmart
	 */
	public IKTokenizer(Reader in , boolean useSmart){
	    super(in);
		arrWord = new char[4096];
		char cTmp = 0;
		iWordLength = 0;
		try {
			while( (cTmp = (char)in.read()) != 65535)
				arrWord[iWordLength++] = cTmp;
		} catch (IOException e) {
			e.printStackTrace();
		}
		inReader = new StringReader(new String(arrWord, 0, iWordLength));
	    offsetAtt = addAttribute(OffsetAttribute.class);
	    termAtt = addAttribute(CharTermAttribute.class);
	    setTermPosSet = new HashSet<TermPos>();
	    iProgress = SMART_ANALYSIS;
	    _SmartIKImplement = new IKSegmenter(inReader , true);
	    _FineIKImplement = new IKSegmenter(inReader, false);
	}

	/* (non-Javadoc)
	 * @see org.apache.lucene.analysis.TokenStream#incrementToken()
	 */
	@Override
	public boolean incrementToken() throws IOException {
		//清除所有的词元属性
		clearAttributes();
		switch(iProgress){
			// 进行智能分词 
			case SMART_ANALYSIS:{
				Lexeme nextLexeme = _SmartIKImplement.next();
				if(nextLexeme != null){
					//将Lexeme转成Attributes
					//设置词元文本
					termAtt.append(nextLexeme.getLexemeText());
					//设置词元长度
					termAtt.setLength(nextLexeme.getLength());
					//设置词元位移
					offsetAtt.setOffset(nextLexeme.getBeginPosition(), nextLexeme.getEndPosition());
					//记录分词的最后位置
					finalOffset = nextLexeme.getEndPosition();
					
					// 添加一个分词位置信息到Set
					setTermPosSet.add(new TermPos(nextLexeme.getBeginPosition(), nextLexeme.getEndPosition()));
					
					//返会true告知还有下个词元
					return true;
				}else{
					// 转到细粒度分词步骤
					iProgress = FINE_ANALYSIS;
					inReader.reset();
					return incrementToken();
				}
			}
			
			// 进行细粒度分词
			case FINE_ANALYSIS:{
				Lexeme nextLexeme = null;
				while( (nextLexeme = _FineIKImplement.next()) != null){			
					if(nextLexeme != null){
						//将Lexeme转成Attributes
						//设置词元文本
						termAtt.append(nextLexeme.getLexemeText());
						//设置词元长度
						termAtt.setLength(nextLexeme.getLength());
						//设置词元位移
						offsetAtt.setOffset(nextLexeme.getBeginPosition(), nextLexeme.getEndPosition());
						//记录分词的最后位置
						finalOffset = nextLexeme.getEndPosition();
						
						// 若已经添加过，则继续找下一个
						if( setTermPosSet.contains(new TermPos(nextLexeme.getBeginPosition(), nextLexeme.getEndPosition())))
								continue;
						
						// 添加一个分词位置信息到Set
						setTermPosSet.add(new TermPos(nextLexeme.getBeginPosition(), nextLexeme.getEndPosition()));
						
						//返会true告知还有下个词元
						return true;
					}
				}
				
				// 转到补充词步骤
				iProgress = ADD_ANALYSIS;
				return incrementToken();				
			}
			
			// 进行补充分词。目的是将某些分词情况下没有出现的非停用词增加到分词中。
			// 只处理由开头分词的情况下，丢失的非停用词
			case ADD_ANALYSIS:{
				// 若还没有处理过，则找到所有补充词
				if(listAddWord == null){
					FindAddWord();
					// 若不存在补充词则词元输出完毕
					if(listAddWord == null)
						return false;
					
					iAddIndex = 0;					
				}
				
				// 返回补充词
				if(iAddIndex < listAddWord.size()){
					int iPos = listAddWord.get(iAddIndex);
					iAddIndex++;
					
					//设置词元文本
					termAtt.append(arrWord[iPos]);
					//设置词元长度
					termAtt.setLength(1);
					//设置词元位移
					offsetAtt.setOffset(iPos, iPos+1);
					//记录分词的最后位置
					finalOffset = iPos+1;					
					return true;
				}		
			}	
			break;
		}			
		
		//返会false告知词元输出完毕
		return false;
	}

	
	/*
	 * (non-Javadoc)
	 * @see org.apache.lucene.analysis.Tokenizer#reset(java.io.Reader)
	 */
	public void reset(Reader input) throws IOException {
		super.reset(input);
		char cTmp = 0;
		iWordLength = 0;
		try {
			while( (cTmp = (char)input.read()) != 65535)
				arrWord[iWordLength++] = cTmp;

		} catch (IOException e) {
			e.printStackTrace();
		}
		inReader = new StringReader(new String(arrWord, 0, iWordLength));
	    setTermPosSet.clear();
	    iProgress = SMART_ANALYSIS;
	    listAddWord = null;
	    
	    
		_SmartIKImplement.reset(inReader);
		_FineIKImplement.reset(inReader);
	}	
	
	@Override
	public final void end() {
	    // set final offset 
		offsetAtt.setOffset(finalOffset, finalOffset);
	}
	/**
	 * 查找补充词
	 */
	private void FindAddWord(){
		// 得到所有分词TermPos
		TermPos[] arrTermPos = setTermPosSet.toArray(new TermPos[0]);
		int iCount = arrTermPos.length;
		if( iCount == 0 )
			return;
		
		// 对所有结果进行排序
		Arrays.sort(arrTermPos, new TermPos(0,0));
				
		int iStartPos = arrTermPos[0].iStart;
		
		// 若位置最前的字不是从第一个开始的则判断是否需要补充前面的字
		listAddWord = new ArrayList<Integer>();
		
		if(iStartPos != 0){
			for(int i = 0; i < iStartPos; i++){
				// 若不是需要补充的字符则继续
				if(!IsAddChar(arrWord[iStartPos]))
					continue;
				
				// 若不是停用词则需要补充
				if( !Dictionary.getSingleton().isStopWord(arrWord, i, 1))
					listAddWord.add(i);
			}
		}
		
		// 判断后续是否有需要补充的词
		HashSet<Integer> setStartPos = new HashSet<Integer>();
		HashSet<Integer> setEndPos = new HashSet<Integer>();
		for(int i = 0; i < iCount; i++){
			TermPos pos = arrTermPos[i];
			
			// 若已经不是从最开头起始的位置了，则停止
			if(pos.iStart != iStartPos)
				break;
			
			// 若当前分词本身已经包含所有全词则继续
			if(pos.iEnd == iWordLength)
				continue;
			
			// 判断当前起始的位置后续是否能够连接成全词	
			setStartPos.clear();
			setEndPos.clear();
			setStartPos.add(pos.iEnd);
			while(true){
				// 添加所有由起始位置开始的结束位置
				for(int j = i+1; j < iCount; j++){
					// 若找到下一个位置，则添加到End Set
					if(setStartPos.contains(arrTermPos[j].iStart)){
						// 若下一个位置已经包含全词则停止
						if(arrTermPos[j].iEnd == iWordLength){
							setStartPos.clear();
							break;
						}else
							setEndPos.add(arrTermPos[j].iEnd);						
					}
				}
				
				// 若已经找到全词，则停止
				if(setStartPos.size() == 0)
					break;
				
				// 若找到下一个位置
				if(setEndPos.size() != 0){
					// 交换起止set，同时将end set 置空
					HashSet<Integer> tmp = setStartPos;
					setStartPos = setEndPos;
					setEndPos = tmp;
					setEndPos.clear();
				}else{
					// 找到最靠后的起始字
					int iLastPos = 0;
					for(Integer tmp : setStartPos ){
						if(tmp > iLastPos)
							iLastPos = tmp;
					}
					
					// 若是补充词，且不是停用词则添加到补充词列表
					if(IsAddChar(arrWord[iLastPos]) 
							&& !Dictionary.getSingleton().isStopWord(arrWord, iLastPos, 1)){
						listAddWord.add(iLastPos);
					}
					
					// 若下一个位置就是全词则停止
					if(iLastPos + 1 == iWordLength)
						break;
					
					// 将下一个位置添加到起始数组
					setStartPos.clear();
					setEndPos.clear();
					setStartPos.add(iLastPos + 1);
				}
			}
		}
	}
	
	/**
	 * 判断指定字符是否为需要补充的字符
	 * @param Char 
	 * @return 是可检索字符返回true,否则返回false
	 */
	public boolean IsAddChar(char Char){
		// 若为简体汉字
		if(Char >= 0x4E00 && Char <= 0x9FA5){
			return true;
		}
		
		// 若为数字
		if( ( Char >= 0x0030 && Char <= 0x0039 ) /* 半角 */
			|| ( Char >= 0xFF10 && Char <=  0xFF19 ) /* 全角 */ ){
			return true;
		}
		
		// 若位字母
//		if( (Char >= 0x0041 && Char <= 0x005A ) /*半角大写*/
//			|| (Char >= 0x0061 && Char <= 0x007A ) /*半角小写*/
//			|| (Char >= 0xFF21 && Char <= 0xFF3A ) /*全角大写*/
//			|| (Char >= 0xFF41 && Char <= 0xFF5A ) /*全角小写*/ ){
//			return true;
//		}
		
		return false;
	}
}

class TermPos implements Comparator<Object>{
	int iStart = 0;
	int iEnd = 0;
	
	TermPos(int iStart, int iEnd){
		this.iStart = iStart;
		this.iEnd = iEnd;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + iEnd;
		result = prime * result + iStart;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final TermPos other = (TermPos) obj;
		if (iEnd != other.iEnd)
			return false;
		if (iStart != other.iStart)
			return false;
		return true;
	}

	public int compare(Object o1, Object o2) {
		TermPos pos1 = (TermPos)o1;
		TermPos pos2 = (TermPos)o2;
		if(pos2.iStart < pos1.iStart)
			return 1;
		else if(pos2.iStart > pos1.iStart)
			return -1;
		else
			return 0;
	}
}