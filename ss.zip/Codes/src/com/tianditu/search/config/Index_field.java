package com.tianditu.search.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Index_field {
	public String name;
	public String isIndexed;
	public String isStored;
	public String defaultvaule;
	// 增加域类型，普通域存储和索引，type=boost时只负责加权
	public String type;
	//增加直接使用数组下标访问方式
	public String pos;
	public HashMap<String, Float> boosts;
	//内容映射
	public HashMap<String,String> mapping;
	//只保留包含在表中的条目数局
	public ArrayList<String> filter;
	//如果包含在表中的条目，去除
	public ArrayList<String> remove;
	
	//操作方式
	public String action;
	//子项目数组
	//public ArrayList<Index_field> subfield;
	public LinkedHashMap<String,Index_field> subfield;
	public Index_field() {

		super();
		boosts = new HashMap<String, Float>();
		filter = new ArrayList<String>();
		mapping = new HashMap<String,String>();
		remove = new ArrayList<String>();
		// TODO Auto-generated constructor stub
	}

	public void AddFilter(String ft){
		filter.add(ft);
	}
	
	public void AddRemove(String re){
		remove.add(re);
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsIndexed() {
		return isIndexed;
	}

	public void setIsIndexed(String isIndexed) {
		this.isIndexed = isIndexed;
	}

	public String getIsStored() {
		return isStored;
	}

	public void setIsStored(String isStored) {
		this.isStored = isStored;
	}

	public HashMap<String, Float> getBoosts() {
		return boosts;
	}

	public void setBoosts(HashMap<String, Float> boosts) {
		this.boosts = boosts;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
