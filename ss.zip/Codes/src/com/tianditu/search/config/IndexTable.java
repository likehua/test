package com.tianditu.search.config;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;
/**
 * 对应配置表中的数据的一个源 column
 * @author chenxinfeng
 *
 */
public class IndexTable {
	public String source_path;
	public String source_encoding;
	public String split;
	public LinkedHashMap<String,Index_field> field;
	//整个源的
	public float source_boost;
	//源内容的特殊处理
	public String filter_action;
	//源名字
	public String name;
	//分级索引key位置
	public String laykey_pos;
	//多源文件后缀
	public String source_suffix;
	
	
	
	public float getSource_boost() {
		return source_boost;
	}

	public void setSource_boost(float source_boost) {
		this.source_boost = source_boost;
	}

	public String getFilter_action() {
		return filter_action;
	}

	public void setFilter_action(String filter_action) {
		this.filter_action = filter_action;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSource_path() {
		return source_path;
	}

	public void setSource_path(String source_path) {
		this.source_path = source_path;
	}

	public String getSource_encoding() {
		return source_encoding;
	}

	public void setSource_encoding(String source_encoding) {
		this.source_encoding = source_encoding;
	}

	public IndexTable() {
		super();
		field = new LinkedHashMap<String,Index_field>();
		source_path = "";
	}

	/**
	 * 获得源数据地址
	 * @return
	 */
	public String getIndex_name() {
		return source_path;
	}

	public void setIndex_name(String index_name) {
		this.source_path = index_name;
	}

	public HashMap<String, Index_field> getField() {
		return field;
	}

	public void setField(LinkedHashMap<String, Index_field> field) {
		this.field = field;
	}

	public boolean addField(String name,Index_field index_field){
		field.put(name, index_field);
		return true;
	}
	
	public String getSQL(){
		String sql = "select ";
		String fie = "";
		for(String ke:field.keySet()){
			fie+=","+ke;
		}
		fie = fie.replaceFirst(",", "");
		sql+=fie+" from "+source_path;
		return sql;
	}

	public String getSplit() {
		return split;
	}

	public void setSplit(String split) {
		this.split = split;
	}

	public String getLaykey_pos() {
		return laykey_pos;
	}

	public void setLaykey_pos(String laykey_pos) {
		this.laykey_pos = laykey_pos;
	}

	public String getSource_suffix() {
		return source_suffix;
	}

	public void setSource_suffix(String source_suffix) {
		this.source_suffix = source_suffix;
	}
}
