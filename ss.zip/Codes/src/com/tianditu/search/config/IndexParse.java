package com.tianditu.search.config;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
/**
 * 
 *@author chenxinfeng
 *@since 2012年10月23日
 */
public class IndexParse {
	
	
	/**
	 * 将配置中的filed类映射到index_field中
	 * @param columns xml中的包含field的列
	 * @return 返回域名和域信息的链哈希表
	 */
	public LinkedHashMap<String,Index_field> GetIndexField(Element columns){
		if(columns==null)
			return null;
		LinkedHashMap<String,Index_field> result = new LinkedHashMap<String,Index_field>();
		for (Iterator j = columns.elementIterator("field"); j.hasNext();) {
			Index_field indexfield = new Index_field();

			Element field = (Element) j.next();
			String fidle_name = field.elementText("name");
			String isIndexed =field
					.elementText("indexed");
			String isStored =field
					.elementText("stored");
			String defaultvalue = field.elementText("value");
			String action = field.elementText("action");
			String field_type = field.attributeValue("type");
			String pos = field.elementText("pos");
			indexfield.name = fidle_name;
			indexfield.isIndexed = isIndexed;
			indexfield.isStored = isStored;
			indexfield.type = field_type;
			indexfield.defaultvaule = defaultvalue;
			indexfield.action = action;
			indexfield.pos = pos;
			//权值映射
			for(Iterator b = field.elementIterator("boost");b.hasNext();){
				Element bs = (Element)b.next();
				String bs_name = bs.attributeValue("name");
				String bs_value = bs.attributeValue("value");
				Float va = Float.valueOf(bs_value);
				indexfield.boosts.put(bs_name, va);
			}
			//值射域
			for(Iterator b = field.elementIterator("maping");b.hasNext();){
				Element bs = (Element)b.next();
				String bs_name = bs.attributeValue("name");
				String bs_value = bs.attributeValue("value");
				indexfield.mapping.put(bs_name, bs_value);
			}
			//保留值
			for(Iterator b = field.elementIterator("filter");b.hasNext();){
				Element bs = (Element)b.next();
				String filtervalue = bs.getText();
				indexfield.AddFilter(filtervalue);
			}
			
			//删除值
			for(Iterator b = field.elementIterator("remove");b.hasNext();){
				Element bs = (Element)b.next();
				String filtervalue = bs.getText();
				indexfield.AddRemove(filtervalue);
			}
			
			Element subfields = field.element("subfield");
			indexfield.subfield = GetIndexField(subfields);
			
			
			result.put(fidle_name, indexfield);
			//tab.addField(fidle_name, indexfield);
		}
		return result;
		
	}
	
	public  LinkedHashMap<String,DataIndex> getIndexTable(String index_path){
		LinkedHashMap<String, DataIndex> indexs = new LinkedHashMap<String, DataIndex>();
		File f = new File(index_path);
		SAXReader reader = new SAXReader();
		Document doc = null;
		try {
			doc = reader.read(f);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element root = doc.getRootElement();
		for (Iterator i = root.elementIterator("index"); i.hasNext();) {

			DataIndex table = new DataIndex();
			Element foo = (Element) i.next();
			String index_name = foo.elementText("indexname");
			System.out.println(index_name);
			table.index_name = index_name;
			table.analyzer = foo.elementText("analyzer");
			String field_string = "";
			//Element columns = foo.elementIterator("column");
			for(Iterator colums = foo.elementIterator("column");colums.hasNext();){
				
				Element columns = (Element)colums.next();
				
				IndexTable tab = new IndexTable();
				tab.source_path = columns.elementText("source");
				tab.source_encoding =columns.elementText("encoding");
				tab.split = columns.elementText("split");
				tab.filter_action = columns.elementText("filter_action");
				tab.name = columns.attributeValue("name");
				tab.laykey_pos = columns.elementText("laykey_pos");
				tab.source_suffix = columns.elementText("source_suffix");
				String source_boost = columns.attributeValue("boost");
				if(source_boost!=null&&!source_boost.equalsIgnoreCase("")){
					tab.source_boost = Float.parseFloat(source_boost);
				}
				//增加域信息
				tab.field =GetIndexField(columns);
				table.addSource(tab);
			}
			indexs.put(index_name, table);
		}
			
		
		System.out.println(indexs);
		return indexs;
	}
	
	public static void main(String[] args) {
		IndexParse parse  = new IndexParse();
		parse.getIndexTable("e:\\data\\poi_index.xml");
		System.out.println("Hello World");
	
	}
}
