package com.tianditu.search.config;

import java.util.LinkedList;

public class DataIndex {
	public String index_name;
	public  LinkedList<IndexTable> source;
	//分词器名称
	public String analyzer;
	
	
	public String getAnalyzer() {
		return analyzer;
	}
	public void setAnalyzer(String analyzer) {
		this.analyzer = analyzer;
	}
	protected DataIndex() {
		super();
		source = new LinkedList<IndexTable>();
		// TODO Auto-generated constructor stub
	}
	public String getIndex_name() {
		return index_name;
	}
	public void setIndex_name(String index_name) {
		this.index_name = index_name;
	}
	public LinkedList<IndexTable> getSource() {
		return source;
	}
	public void setSource(LinkedList<IndexTable> source) {
		this.source = source;
	}
	public void addSource(IndexTable tab){
		source.add(tab);
	}
	
}
