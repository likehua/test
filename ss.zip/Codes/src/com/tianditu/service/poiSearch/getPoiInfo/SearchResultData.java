package com.tianditu.service.poiSearch.getPoiInfo;

import java.io.Serializable;

public class SearchResultData implements Serializable {

	/**
	 * 
	 */

	private static final long serialVersionUID = 167780451304305501L;

	/**
	 * @param args
	 */
	// private static final long serialVersionUID = 1L;
	// POI 名称
	private String m_Name;
	// POI 地址
	private String m_Address;
	// POI 电话
	private String m_Phone;
	// POI 纬度
	private long m_iLat;
	// 数字形式的地坄1�7
	private long m_iLon;
	// 行政区码
	private int m_CityCode;
	// poi 类型
	private int m_Type;

	// poi距离
	public int m_Distance = 0;

	public String getName() {
		return m_Name;
	}

	public void setName(String Name) {
		m_Name = Name;
	}

	public String getAddress() {
		return m_Address;
	}

	public void setAddress(String Address) {
		m_Address = Address;
	}

	public String getPhone() {
		return m_Phone;
	}

	public void setPhone(String Phone) {
		m_Phone = Phone;
	}

	public long getM_iLat() {
		return m_iLat;
	}

	public void setM_iLat(long lat) {
		m_iLat = lat;
	}

	public long getM_iLon() {
		return m_iLon;
	}

	public void setM_iLon(long lon) {
		m_iLon = lon;
	}

	public int getM_CityCode() {
		return m_CityCode;
	}

	public void setM_CityCode(int cityCode) {
		m_CityCode = cityCode;
	}

	public int getM_Type() {
		return m_Type;
	}

	public void setM_Type(int type) {
		m_Type = type;
	}

	public void setM_Dis(int dis) {
		m_Distance = dis;
	}

	public int getM_Dis() {
		return m_Distance;
	}

	public String toString() {
		final StringBuilder buffer = new StringBuilder();
		buffer.append(this.m_Name + " ");
		buffer.append(this.m_Address + " ");
		buffer.append(this.m_Phone + " ");
		buffer.append(this.m_iLat + " ");
		buffer.append(this.m_iLon + " ");
		buffer.append(this.m_Distance + " ");

		return buffer.toString();
	}

}
