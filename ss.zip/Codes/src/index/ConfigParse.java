package index;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

import log.DataDecodeLog;


public class ConfigParse {

	/**
	 * @param args
	 */
	/**
	 * 存放索引文本文件
	 */
	public String m_IndexFile = null;
	/**
	 * 存放提示词文件
	 */
	public String m_HelpFile = null;
	/**
	 * 分级存放目录
	 */
	public String m_LevelName = null;
	/**
	 * 全国索引目录
	 */
	public String m_GlobalName = null;
	/**
	 * 提示词索引目录
	 */
	public String m_HelpName = null;
	//存放分级索引的文件分级
	public String m_FileIndex = null;
	//存放行政区编码配置文件
	public String m_CodeName = null;
	//存放公交数据的文件
	public String m_BusName = null;
	//存放数据库的导出索引的原始文件
	public String m_IndexSource = null;
	//存放数据库的提示词道出的原始文件
	public String m_HelpSource = null;
	//存放提示词需要的配置文件
	public String m_HelpCode = null;
	//存放导出提示词的配置文件
	public String m_Location = null;
	
	//存放导出地标文件的位置
	public String m_Landmark = null;
	//POISQL语句
	public String m_poiSql=null;
	//提示词SQL语句
	public String m_pinyinSql=null;
	/**
	 * 索引文本配置文件
	 */
	public String IndexXMLFile = null;
	/**
	 * 提示词配置文件
	 */
	public String HelpXMLFile = null;
	/**
	 * 分级配置表文件
	 */
	public String IndexPath = null;
	
	public String SearchLog = null;
	
	public String engine_version = null;
	
	public String search_version = null;
	
	static final String ConfigPath ="E:/data/config.txt";
	static final String TEXTFILE = "IndexText";
	static final String HELPFILE = "HelpText";
	static final String LEVELNAME = "LevelIndex";
	static final String GLOBALNAME = "GlobalIndex";
	static final String HELPNAME = "PinyinIndex";
	static final String FILELEVEL = "IndexFile";
	static final String CODENAME = "CodeName";
	static final String BUSNAME = "BusName";
	static final String HELPSOR = "ImportHelpText";
	static final String INDEXSOR = "ImportIndexText";
	static final String HELPCODE = "HelpCode";
	static final String LOCATION = "Location";
	
	//jdbc driver class
	public static String DRIVER_CLASS;
	
	//jdbc url 
	public static String JDBC_URL;
	
	
	//jdbc user name param
	public static String JDBC_USER;
	
	//jdbc password param
	public static String JDBC_PASSWORD;
	
	public boolean ParseConfig(String filePath) {
		// 读取配置文件
		try {
			FileReader fIn = new FileReader(filePath);
			BufferedReader reader = new BufferedReader(fIn);

			// 解析输入目录
			String strLine = null;
			
			while ((strLine = reader.readLine()) != null) {
				// 去掉空行 和 注释
				strLine = strLine.trim();
				if (strLine.isEmpty()) {
					continue;
				}
				if(strLine.startsWith("#"))
				{
					continue;
				}

				// 找到带有配置文件的行
				int iPos = strLine.indexOf("=");
				if(iPos > 0)
				{
					String[] arrItem = strLine.split("=");
					if(arrItem[0].equalsIgnoreCase(TEXTFILE))
					{
						m_IndexFile = arrItem[1];
						System.out.println(m_IndexFile );
					}
					if(arrItem[0].equalsIgnoreCase(HELPFILE))
					{
						m_HelpFile = arrItem[1];
						System.out.println(m_HelpFile );
					}
					if(arrItem[0].equalsIgnoreCase(LEVELNAME))
					{
						m_LevelName = arrItem[1];
						System.out.println(m_LevelName );
					}
					if(arrItem[0].equalsIgnoreCase(GLOBALNAME))
					{
						m_GlobalName = arrItem[1];
						System.out.println(	m_GlobalName );
					}
					if(arrItem[0].equalsIgnoreCase(HELPNAME))
					{
						m_HelpName = arrItem[1];
						System.out.println(m_HelpName );
					}
					if(arrItem[0].equalsIgnoreCase(FILELEVEL))
					{
						m_FileIndex = arrItem[1];
						System.out.println(m_FileIndex );
					}
					if(arrItem[0].equalsIgnoreCase(CODENAME))
					{
						m_CodeName = arrItem[1];
						System.out.println(m_CodeName );
					}
					if(arrItem[0].equalsIgnoreCase(BUSNAME))
					{
						m_BusName = arrItem[1];
						System.out.println(m_BusName );
					}
					if(arrItem[0].equalsIgnoreCase(HELPSOR))
					{
						m_HelpSource = arrItem[1];
						System.out.println(m_HelpSource );
					}
					if(arrItem[0].equalsIgnoreCase(INDEXSOR))
					{
						m_IndexSource = arrItem[1];
						System.out.println(m_IndexSource );
					}
					if(arrItem[0].equalsIgnoreCase(HELPCODE))
					{
						m_HelpCode = arrItem[1];
						System.out.println(m_HelpCode );
					}
					if(arrItem[0].equalsIgnoreCase(LOCATION))
					{
						m_Location = arrItem[1];
						System.out.println(m_Location);
					}
					if(arrItem[0].equalsIgnoreCase("IndexXMLFile"))
					{
						IndexXMLFile = arrItem[1];
						System.out.println(IndexXMLFile);
					}
					if(arrItem[0].equalsIgnoreCase("IndexPath"))
					{
						IndexPath = arrItem[1];
						System.out.println(IndexPath);
					}
					if(arrItem[0].equalsIgnoreCase("HelpXMLFile"))
					{
						HelpXMLFile = arrItem[1];
						System.out.println(HelpXMLFile);
					}
					if(arrItem[0].equalsIgnoreCase("SearchLog"))
					{
						SearchLog = arrItem[1];
						System.out.println(SearchLog);
					}
					
					if(arrItem[0].equalsIgnoreCase("engine_version"))
					{
						engine_version = arrItem[1];
						System.out.println(engine_version);
					}
					
					if(arrItem[0].equalsIgnoreCase("search_version"))
					{
						search_version = arrItem[1];
						System.out.println(search_version);
					}
					
					if(arrItem[0].equalsIgnoreCase("DRIVER_CLASS"))
					{
						//search_version = arrItem[1];
						DRIVER_CLASS = arrItem[1];
						System.out.println(DRIVER_CLASS);
					}
					
					
					if(arrItem[0].equalsIgnoreCase("JDBC_URL"))
					{
						//search_version = arrItem[1];
						JDBC_URL = arrItem[1];
						System.out.println(JDBC_URL);
					}
					
					
					if(arrItem[0].equalsIgnoreCase("JDBC_USER"))
					{
						//search_version = arrItem[1];
						JDBC_USER = arrItem[1];
						System.out.println(JDBC_USER);
					}
					
					
					if(arrItem[0].equalsIgnoreCase("JDBC_PASSWORD"))
					{
						//search_version = arrItem[1];
						JDBC_PASSWORD = arrItem[1];
						System.out.println(JDBC_PASSWORD);
					}
					
					
					
					if(arrItem[0].equalsIgnoreCase("ExportLandmark"))
					{
						m_Landmark = arrItem[1];
						System.out.println(m_Landmark);
					}
					if(arrItem[0].equalsIgnoreCase("poi_sql"))
					{
						this.m_poiSql="";
						if(arrItem.length>2){
							for(int i=1;i<arrItem.length-1;i++){
								this.m_poiSql+= arrItem[i]+"=";
							}
							this.m_poiSql += arrItem[arrItem.length-1];
							System.out.println(this.m_poiSql);
						}else{
							this.m_poiSql = arrItem[1];
						}
						System.out.println(m_poiSql);
					}
					if(arrItem[0].equalsIgnoreCase("pinyin_sql"))
					{
						this.m_pinyinSql="";
						if(arrItem.length>2){
							for(int i=1;i<arrItem.length-1;i++){
								this.m_pinyinSql += arrItem[i]+"=";
							}
							this.m_pinyinSql  += arrItem[arrItem.length-1];
							//System.out.println(this.m_pinyinSql );
							
							//this.m_pinyinSql = arrItem[1]+"="+arrItem[2];
						}else{
							this.m_pinyinSql = arrItem[1];
						}
						System.out.println(m_pinyinSql);
					}
				}
			}
			reader.close();
			fIn.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConfigParse test = new ConfigParse();
		test.ParseConfig("");
	}

}
