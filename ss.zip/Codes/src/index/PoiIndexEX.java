package index;

import help.HelpSearch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import log.DataDecodeLog;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.wltea.analyzer.lucene.IKAnalyzer;

import singleAnalyzer.SingleAnalyzer;

import com.tianditu.search.config.DataIndex;
import com.tianditu.search.config.IndexParse;
import com.tianditu.search.config.IndexTable;
import com.tianditu.search.config.Index_field;

public class PoiIndexEX {

	/**
	 * @param args
	 */
	static final String CFG_FILE_PATH = "res/fileDir.cfg";
	static final String CFG_CFG_START = "<Generate>";
	static final String CFG_CFG_END = "</Generate>";

	static final String FLAG_IN_DIR = "InDir";
	static final String FLAG_OUT_DIR = "OutDir";
	protected String m_strInDir = null;
	protected String m_strOutDir = null;
	
	public String engine_version ="tdtdata2014";
	public String search_version ="tdtsearch2014";

	Map<String, String> typeMap = new HashMap<String, String>();

	protected boolean ParseConfig() {
		// 读取配置文件
		try {
			FileReader fIn = new FileReader(CFG_FILE_PATH);
			BufferedReader reader = new BufferedReader(fIn);

			// 解析输入目录
			String strLine = null;
			boolean bIsCfgStart = false;
			while ((strLine = reader.readLine()) != null) {
				// 去掉注释
				int iPos = strLine.indexOf("#");
				if (iPos >= 0) {
					strLine = strLine.substring(0, iPos);
				}

				strLine = strLine.trim();
				if (strLine.isEmpty()) {
					continue;
				}

				// 找到配置弄1�7�1�7�处
				if (strLine.equalsIgnoreCase(CFG_CFG_START)) {
					bIsCfgStart = true;
				} else if (!bIsCfgStart) {
					continue;
				} else if (strLine.equalsIgnoreCase(CFG_CFG_END)) {
					break;
				} else {
					String[] arrItem = strLine.split("=");
					if (arrItem[0].equalsIgnoreCase(FLAG_IN_DIR)) {
						m_strInDir = arrItem[1];
						System.out.println(m_strInDir);
					}
					if (arrItem[0].equalsIgnoreCase(FLAG_OUT_DIR)) {
						m_strOutDir = arrItem[1];
						System.out.println(m_strOutDir);
					}
				}
			}
			reader.close();
			fIn.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public ArrayList<String> BianLi(String dirname) {

		ArrayList<File> list = new ArrayList<File>();
		ArrayList<String> fileL = new ArrayList<String>();
		File file = new File(dirname);
		File[] files = file.listFiles();
		for (int i = 0; i < files.length; i++) {
			// System.out.println("size is:"+files.length);
			if (files[i].isDirectory() && files[i] != null) {
				list.add(files[i]);

			} else {

				System.out.println(files[i].getAbsolutePath() + "aaaa");
			}
		}
		File temp;
		// System.out.println("List size is:"+list.size());
		while (!list.isEmpty()) {
			temp = (File) list.remove(0);

			// System.out.println("aaaaaa+++:"+tmep);
			int j = 0;
			if (temp.isDirectory()) {
				files = temp.listFiles();
				if (files != null) {
					for (int i = 0; i < files.length; i++) {
						if (files[i].isDirectory()) {
							list.add(files[i]);
							j++;
						} else {
							for (int k = 0; k < j; k++) {
								System.out.print("+");

							}
							fileL.add(files[i].getAbsolutePath());

						}
					}
				} else {
					continue;
				}
			} else {
				fileL.add("fileL :" + temp.getAbsolutePath());
				;// System.out.println(j);
			}

		}

		return fileL;
	}

	public static boolean check(String fstrData) {
		char c = fstrData.charAt(0);
		if (((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {
			return true;
		} else {
			return false;
		}
	}

	// 去除后边空格
	public String TrimZero(String word) {
		String result = null;

		if (word.endsWith("0000"))
			result = word.substring(0, 2);
		else if (word.endsWith("00"))
			result = word.substring(0, 4);
		else
			result = word;

		return result;
	}

	public void loadClass(String fileName) {
		try {
			File file = new File(fileName);
			FileInputStream fi = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fi, "GBK");// ,
			// "utf-8"
			BufferedReader reader = new BufferedReader(isr);

			String tempString = null;
			int count = 0;

			while ((tempString = reader.readLine()) != null) {

				// System.out.println(tempString);

				if (tempString != null) {

					count++;
					String[] arr = tempString.split(",");
					int num = arr.length;
					arr[0] = arr[0].replace("\"", "");
					arr[1] = arr[1].replace("\"", "");
					// System.out.print(arr.length);

					String key = TrimZero(arr[0]);
					System.out.println(key + "  " + arr[1]);
					typeMap.put(key, arr[1]);
					// System.out.println(arr[0]+" "+arr[num-1]+ " "+count);
				}

			}
			// System.out.println("含有数据数量: "+codeMap.size());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 分割字符为数组
	 * 
	 * @param split
	 * @param tempString
	 * @return
	 */
	public String[] StringToArrayList(String split, String tempString) {
		String[] arr = null;
		if (split.equalsIgnoreCase("\",\"")) {

			arr = tempString.split("\",\"");
			for (int i = 0; i < arr.length; i++) {
				arr[i] = arr[i].replaceAll("\"", "");
			}
		} else {
			arr = tempString.split(split);
		}
		return arr;
	}

	/**
	 * 根据文档内容设置分数
	 * 
	 * @param doc
	 * @param fe
	 * @param content
	 */
	public void Addboost(Document doc, Index_field fe, String content) {
		if (fe.getBoosts().containsKey(content)) {
			float bs = fe.getBoosts().get(content);
			float old_boost = doc.getBoost();
			doc.setBoost(bs*old_boost);
		}
		
		if(fe.getBoosts().containsKey("less2word")&&content.length()<3){
			float bs = fe.getBoosts().get("less2word");
			float old_boost = doc.getBoost();
			doc.setBoost(bs*old_boost);
		}
	}

	/**
	 * 文档过滤，如果含有文档过滤且目前文档不在文档过滤中则返回false
	 * 
	 * @param doc
	 * @param fe
	 * @param content
	 * @return
	 */
	public boolean docFilter(Document doc, Index_field fe, String content) {
		boolean isIgnore = false;
		if (fe.filter.size() > 0) {
			isIgnore = true;
			for (String ft : fe.filter) {
				if (content.contains(ft)) {
					isIgnore = false;
					break;
				}
			}
			if (isIgnore) {
				return isIgnore;
			}
		}
		return isIgnore;
	}

	/**
	 * 文档过滤，如果含有文档删除且目前文档在文档删除中则返回true
	 * 
	 * @param doc
	 * @param fe
	 * @param content
	 * @return
	 */
	public boolean docRemove(Document doc, Index_field fe, String content) {
		boolean isIgnore = false;
		if (fe.remove.size() > 0) {
			for (String ft : fe.remove) {
				if (content.contains(ft)) {
					isIgnore = true;
					break;
				}
			}
		}
		return isIgnore;
	}

	/**
	 * 增加一个域到doc中 for 提示词
	 * 
	 * @param doc
	 * @param fe
	 * @param content
	 * @param all_content
	 * @param Db
	 * @return
	 */
	public boolean AddIndexFiledForPrompt(Document doc, Index_field fe,
			String content, String[] all_content, HelpSearch Db) {
		StringAction sa = StringAction.GetInstance();
		boolean isIgnore = false;
		String na = fe.name;
		String field_type = fe.type;
		if (fe.mapping != null && fe.mapping.size() > 0) {
			content = fe.mapping.get(content);
		}

		if (content == null)
			content = "";

		// 如果还有子域，则处理子域
		if (fe.subfield != null && fe.subfield.size() > 0) {
			String[] subarr = null;
			if (fe.action.equalsIgnoreCase("dividetolonandlat")) {
				subarr = (String[]) sa.dividetolonandlat(content, ",");
			} else if (fe.action
					.equalsIgnoreCase("parseNameAndNameStoreForBus")) {
				subarr = sa.parseNameAndNameStoreForBus(content, doc,
						all_content);
			} else if (fe.action.equalsIgnoreCase("parseLocationAndTotalcity")) {
				//
				subarr = sa.parseLocationAndTotalcity(content, all_content, Db);
			}
			else if (fe.action.equalsIgnoreCase("parseLocationAndTotalcityForBusExit")) {
				//
				subarr = sa.parseLocationAndTotalcityForBusExit(content, all_content, Db);
			}else if (fe.action.equalsIgnoreCase("parseLocationAndTotalcityForBusLine")) {
				//
				subarr = sa.parseLocationAndTotalcityForBusLine(content, all_content, Db);
			}else if (fe.action.equalsIgnoreCase("parseLocationAndTotalcityForBus")) {
				//
				subarr = sa.parseLocationAndTotalcityForBus(content, all_content, Db);
			}  else {
				try {
					Class ptypes = Class.forName("java.lang.String");
					Class ptypes2 = String[].class;
					Object arg[] = new Object[2];
					arg[0] = content;
					arg[1] = all_content;
					Method m = StringAction.class.getMethod(fe.action, ptypes,
							ptypes2);
					subarr = (String[]) m.invoke(sa, arg);
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			// 对子域的处理
			int subi_arr = 0;
			for (Index_field sufie : fe.subfield.values()) {
				String subcontent = "";
				if ("useradd".equalsIgnoreCase(fe.type)) {
					content = fe.defaultvaule;
				} else {
					content = subarr[subi_arr++];// 取过内容后域加+1
				}

				if (content == null)
					content = "";

				isIgnore = AddIndexFiledForPrompt(doc, sufie, content,
						all_content, Db);
				// 如果为忽略想停止
				if (isIgnore)
					break;
			}
			return isIgnore;
		}

		Store stored_conf = Field.Store.NO;
		Index indexed_conf = Field.Index.NO;
		// 映射索引相关
		if (fe.isIndexed.equalsIgnoreCase("NO")) {
			indexed_conf = Field.Index.NO;
		} else if (fe.isIndexed.equalsIgnoreCase("NOT_ANALYZED")) {
			indexed_conf = Field.Index.NOT_ANALYZED;
		} else if (fe.isIndexed.equalsIgnoreCase("NOT_ANALYZED_NO_NORMS")) {
			indexed_conf = Field.Index.NOT_ANALYZED_NO_NORMS;
		}
		if (fe.isIndexed.equalsIgnoreCase("ANALYZED")) {
			indexed_conf = Field.Index.ANALYZED;
		} else if (fe.isIndexed.equalsIgnoreCase("ANALYZED_NO_NORMS")) {
			indexed_conf = Field.Index.ANALYZED_NO_NORMS;
		}
		// 映射存储相关
		if (fe.isStored.equalsIgnoreCase("YES"))
			stored_conf = Field.Store.YES;
		else if (fe.isStored.equalsIgnoreCase("NO"))
			stored_conf = Field.Store.NO;

		Addboost(doc, fe, content);
		if (docFilter(doc, fe, content))
			return true;

		if (docRemove(doc, fe, content))
			return true;
		// 利用反射处理action需要处理的内容
		if (fe.action != null) {
			try {
				Class ptypes = Class.forName("java.lang.String");
				Class ptypes2 = String[].class;
				Object arg[] = new Object[2];
				arg[0] = content;
				arg[1] = all_content;
				Method m = StringAction.class.getMethod(fe.action, ptypes,
						ptypes2);
				content = (String) m.invoke(sa, arg);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// 域内容的处理建
		if (field_type != null && field_type.equalsIgnoreCase("ignore")) {
			// 忽略该项，但不忽略本文档
			return isIgnore;
		} else if (field_type != null && field_type.equalsIgnoreCase("boost")) {
			if (!content.equalsIgnoreCase("null")) {
				int num = Integer.parseInt(content);
				float f = doc.getBoost() + (float) num / 10;
				// System.out.println("set boost:"+f);
				doc.setBoost(f);
			}
		} else {
			// 普通域处理
			// System.out.println(na + ":" + content);
			if(fe.isStored.equalsIgnoreCase("NO")&&fe.isIndexed.equalsIgnoreCase("NO")){
				
			}else{
				doc.add(new Field(na, content, stored_conf, indexed_conf));
			}
			// 普通域加权处理
			if (fe.getBoosts().containsKey(content)) {
				float bs = fe.getBoosts().get(content);
				doc.setBoost(bs);
			}
		}
		return isIgnore;
	}

	/**
	 * 增加一个域到doc中
	 * 
	 * @param writer
	 * @param doc
	 * @param fe
	 * @param content
	 * @param all_content
	 * @return
	 */
	public boolean AddIndexFiled(IndexWriter[] writers, Document doc,
			Index_field fe, String content, String[] all_content) {
		StringAction sa =  StringAction.GetInstance();

		IndexWriter writer = writers[0];
		boolean isIgnore = false;
		String na = fe.name;
		String field_type = fe.type;
		if (fe.mapping != null && fe.mapping.size() > 0) {
			content = fe.mapping.get(content);
		}

		if (content == null)
			content = "";
		String origin_content = content;
		// 如果还有子域，则处理子域
		if (fe.subfield != null && fe.subfield.size() > 0) {
			String[] subarr = null;
			if (fe.action.equalsIgnoreCase("dividetolonandlat")) {
				subarr = (String[]) sa.dividetolonandlat(content, ",");
			} else if (fe.action
					.equalsIgnoreCase("parseNameAndNameStoreForBus")) {
				subarr = sa.parseNameAndNameStoreForBus(content, doc,
						all_content);
			} else if (fe.action.equalsIgnoreCase("parseLocationAndTotalcity")) {
				//
				subarr = sa.parseLocationAndTotalcity(content, all_content,
						null);
			} else {
				try {
					Class ptypes = Class.forName("java.lang.String");
					Class ptypes2 = String[].class;
					Object arg[] = new Object[2];
					arg[0] = content;
					arg[1] = all_content;
					Method m = StringAction.class.getMethod(fe.action, ptypes,
							ptypes2);
					subarr = (String[]) m.invoke(sa, arg);
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			// 对子域的处理
			int subi_arr = 0;
			for (Index_field sufie : fe.subfield.values()) {
				String subcontent = "";
				if ("useradd".equalsIgnoreCase(fe.type)) {
					content = fe.defaultvaule;
				} else {
					content = subarr[subi_arr++];// 取过内容后域加+1
				}

				if (content == null)
					content = "";

				isIgnore = AddIndexFiled(writers, doc, sufie, content,
						all_content);
				// 如果为忽略想停止
				if (isIgnore)
					break;
			}
			return isIgnore;
		}

		Store stored_conf = Field.Store.NO;
		Index indexed_conf = Field.Index.NO;
		// 映射索引相关
		if (fe.isIndexed.equalsIgnoreCase("NO")) {
			indexed_conf = Field.Index.NO;
		} else if (fe.isIndexed.equalsIgnoreCase("NOT_ANALYZED")) {
			indexed_conf = Field.Index.NOT_ANALYZED;
		} else if (fe.isIndexed.equalsIgnoreCase("NOT_ANALYZED_NO_NORMS")) {
			indexed_conf = Field.Index.NOT_ANALYZED_NO_NORMS;
		}
		if (fe.isIndexed.equalsIgnoreCase("ANALYZED")) {
			indexed_conf = Field.Index.ANALYZED;
		} else if (fe.isIndexed.equalsIgnoreCase("ANALYZED_NO_NORMS")) {
			indexed_conf = Field.Index.ANALYZED_NO_NORMS;
		}
		// 映射存储相关
		if (fe.isStored.equalsIgnoreCase("YES"))
			stored_conf = Field.Store.YES;
		else if (fe.isStored.equalsIgnoreCase("NO"))
			stored_conf = Field.Store.NO;

		// 增加特殊处理方式，1条数据拆为多个数据，并且停止一下处理，直接跳转到下条数据处理
		if (fe.action != null
				&& fe.action.equalsIgnoreCase("getTotalCityForNewBusLine")) {
			try {
				String[] code = content.split(" ");
				if (docFilter(doc, fe, sa.GetTotalCity(code[0])))
					return true;

				if (docRemove(doc, fe, sa.GetTotalCity(code[0])))
					return true;
				
				sa.getTotalCityForNewBusLine(content, all_content, doc,
								writers);
			} catch (CorruptIndexException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		} else if (fe.action != null) { // 利用反射处理action需要处理的内容
			try {

				Class ptypes = Class.forName("java.lang.String");
				Class ptypes2 = String[].class;
				Object arg[] = new Object[2];
				arg[0] = content;
				arg[1] = all_content;
				Method m = StringAction.class.getMethod(fe.action, ptypes,
						ptypes2);
				content = (String) m.invoke(sa, arg);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Addboost(doc, fe, content);
		if (docFilter(doc, fe, content))
			return true;

		if (docRemove(doc, fe, content))
			return true;

		// 域内容的处理建
		if (field_type != null && field_type.equalsIgnoreCase("ignore")) {
			// 忽略该项，但不忽略本文档
			return isIgnore;
		} else if (field_type != null && field_type.equalsIgnoreCase("boost")) {
			//System.out.println("boost:" + content);
			if (!content.equalsIgnoreCase("null")
					&& !content.equalsIgnoreCase("")) {
				int num = Integer.parseInt(content);
				// 由于1以上开始每隔0.0625才会真正起作用，所以以0.0625为阶梯增长
				float f = doc.getBoost();
				if(num==9){
					 f = (float) (doc.getBoost()*10);
				}else{
					 f = (float) (doc.getBoost() + 0.0625 * num);
				}
				

				// if (tag.length() > 2) {
				// f = f * 3;
				// }
				doc.setBoost(f);
				// d.setBoost(f);
			}
		} else {
			// 普通域处理
			// System.out.println(na + ":" + content);
			doc.add(new Field(na, content, stored_conf, indexed_conf));
			// 普通域加权处理，对比数据时使用原始数据
			if (fe.getBoosts().containsKey(origin_content)) {

				float bs = fe.getBoosts().get(origin_content);
				doc.setBoost(bs);
				// System.out.println("boost:"+origin_content+":"+bs);
			}
		}
		return isIgnore;
	}

	/**
	 * 源数据信息过滤处理
	 * 
	 * @param t
	 *            源配置表
	 * @param arr
	 * @return 返回false过滤，返回true不过滤
	 */
	private boolean FilterSource(IndexTable t, String[] arr, StringAction sa,
			Document doc,Boolean isLay) {
		boolean result = true;
		if (t.filter_action == null)
			return result;

		try {
			Class ptypes = String[].class;
			Object arg[] = new Object[3];
			arg[0] = arr;
			arg[1] = doc;
			arg[2] = isLay;
			Method m = StringAction.class.getMethod(t.filter_action, ptypes,
					Document.class,Boolean.class);
			result = (Boolean) m.invoke(sa, arg);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;

	}

	/**
	 * 根据源和配置表生成索引 for 提示词
	 * 
	 * @param fileName
	 * @param writer
	 * @param t
	 * @throws IOException
	 */
	public void makeTextIndexForPrompt(String fileName, IndexWriter writer,
			IndexTable t, HelpSearch Db) throws IOException {
		
		String source = fileName;
		//if (source == null || source.equals("")) {
			//source = fileName;
		//}
		String encoding = t.getSource_encoding();
		if (encoding == null) {
			encoding = "utf-8";
		}
		float source_boost = t.source_boost;
		String split = t.getSplit();
		if (split == null) {
			split = "####";
		}
		System.out.println("source file:" + source);
		File file = new File(source);
		if(!file.exists()){
			System.out.println(source+" not exits");
			return ;
		}
		FileInputStream fi = new FileInputStream(file);
		InputStreamReader isr = new InputStreamReader(fi, encoding);// , "utf-8"
		BufferedReader reader = new BufferedReader(isr);
		StringAction sa =  StringAction.GetInstance();

		int count = 0;
		try {

			String tempString = null;

			boolean isIgnore = false;
			while ((tempString = reader.readLine()) != null) {
				isIgnore = false;
				try {

					if (tempString != null) {
						Document doc = new Document();
						count++;
						String[] arr = StringToArrayList(split, tempString);

						if (!FilterSource(t, arr, sa, doc,false)){
							//System.out.println(tempString);
							DataDecodeLog.logger.info("remove info:"+tempString);
							continue;
						}
							

						int i_arr = 0;
						for (Index_field fe : t.field.values()) {
							String content = "";
							if ("useradd".equalsIgnoreCase(fe.type)) {
								content = fe.defaultvaule;
							} else if (fe.pos != null) {
								String[] poss = fe.pos.split(",");
								for (String pp : poss) {
									int ip = Integer.parseInt(pp);
									content += arr[ip] + " ";
								}

							} else {
								content = arr[i_arr++];// 取过内容后域加+1
							}

							content = content.trim();
							if (content == null)
								content = "";

							isIgnore = AddIndexFiledForPrompt(doc, fe, content,
									arr, Db);
							// 如果为忽略想停止
							if (isIgnore)
								break;
						}
						if (!isIgnore) {
							if (source_boost > 0) {
								float f = doc.getBoost();
								f = f * source_boost;
								doc.setBoost(f);
							}
							//System.out.println("文档数:" + count);
							writer.addDocument(doc);
						}
					}

				} catch (NullPointerException e) {
					e.printStackTrace();
					System.out.println(tempString);
					DataDecodeLog.logger.error(tempString);
				}
			}

			this.AddVersion(writer);
			
			reader.close();
			DataDecodeLog.logger.info("编译数据	"+fileName+":"+count);
			// fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}

	/**
	 * 根据源和配置表生成索引
	 * 
	 * @param fileName
	 * @param writer
	 *            如果writer不为空则为普通索引编译
	 * @param t
	 * @param l2
	 *            如果writer为空，则使用分级编译
	 * @throws IOException
	 */
	public void makeTextIndexByConfig(String fileName, IndexWriter writer,
			IndexTable t, LayIndex l2) throws IOException {
		
		String source = t.getIndex_name();
		//if (source == null || source.equals("")) {
		if(fileName!=null){
			source = fileName;
		}
		//}
		String encoding = t.getSource_encoding();
		if (encoding == null) {
			encoding = "utf-8";
		}
		float source_boost = t.source_boost;
		String split = t.getSplit();
		if (split == null) {
			split = "####";
		}
		System.out.println("source file:" + source);
		File file = new File(source);
		if(!file.exists()){
			System.out.println(source+" not exits");
			return ;
		}
		FileInputStream fi = new FileInputStream(file);
		InputStreamReader isr = new InputStreamReader(fi, encoding);// , "utf-8"
		BufferedReader reader = new BufferedReader(isr);
		StringAction sa =  StringAction.GetInstance();
		IndexWriter[] writers = null;
		int count = 0;
		try {

			String tempString = null;

			boolean isIgnore = false;
			boolean lastIgnore = false;
			while ((tempString = reader.readLine()) != null) {
				isIgnore = false;
				try {

					if (tempString != null) {
						Document doc = new Document();
						count++;
						String[] arr = StringToArrayList(split, tempString);
						//System.out.println(tempString);

						Boolean isLay =false;
						if(l2!=null){
							isLay = true;
						}
						if (!FilterSource(t, arr, sa, doc,isLay))
							continue;
						if (l2 != null) {
							String laypos = t.laykey_pos;
							if (laypos == null) {
								System.out.println("分级索引key位置不存在");
							}
							int keypos = Integer.parseInt(laypos);
							String keyindex = arr[keypos];
							int start_pos = 3;
							int end_pos=5;
							
							if(keyindex.length()==6){
								start_pos = 0;
								end_pos=2;
							}

							String[] code = keyindex.split(" ");
							if (code[code.length - 1].equals("0")) {
								if (keyindex.length() > 4) {
									keyindex = keyindex.substring(start_pos,end_pos);
								}

								String key = l2.list.get(keyindex);
								if (key == null) {
									//count++;
									continue;
									//key = arr[1];
								}
								//System.out.println("key:" + key);
								writer = l2.ID_map.get(key);

								writers = new IndexWriter[1];
								writers[0] = writer;
							} else {
								String keyindex1 = code[0];
								if (keyindex1.length() > 4) {
									keyindex1 = keyindex1.substring(start_pos,end_pos);
								}

								String key = l2.list.get(keyindex1);
								if (key == null) {
									//count++;
									continue;
									//key = arr[1];
								}
								//System.out.println("key1:" + key);
								writer = l2.ID_map.get(key);

								String keyindex2 = code[code.length - 1];
								if (keyindex2.length() > 4) {
									keyindex2 = keyindex2.substring(start_pos,end_pos);
								}

								String key2 = l2.list.get(keyindex2);
								if (key2 == null) {
									//count++;
									//key2 = arr[1];
									continue;
								}
								//System.out.println("key2:" + key2);
								IndexWriter writer2 = l2.ID_map.get(key2);
								if(writer==null){
									continue;
								}
								writers = new IndexWriter[2];
								writers[0] = writer;
								writers[1] = writer2;
							}
						} else {
							writers = new IndexWriter[1];
							writers[0] = writer;
						}
						int i_arr = 0;
						//System.out.println("%%%%%%%"+tempString);
						for (Index_field fe : t.field.values()) {
							String content = "";
							
							if ("useradd".equalsIgnoreCase(fe.type)) {
								content = fe.defaultvaule;
							} else if (fe.pos != null) {
								String[] poss = fe.pos.split(",");
								//System.out.println(fe.pos);
								for (String pp : poss) {
									int ip = Integer.parseInt(pp);
									if(arr.length>ip){
										content += arr[ip] + " ";
									}else{
										DataDecodeLog.logger.error(ip+"    "+tempString);
										content += " ";
									}
								}

							} else {
								content = arr[i_arr++];// 取过内容后域加+1
							}

							content = content.trim();
							if (content == null)
								content = "";
							
							isIgnore = AddIndexFiled(writers, doc, fe, content,
									arr);
							// 如果为忽略想停止
							if (isIgnore)
								break;
						}
						if (!isIgnore) {
							if (source_boost > 0) {
								float f = doc.getBoost();
								f = f * source_boost;
								doc.setBoost(f);
							}
							//System.out.println("文档数:" + count);
							//DataDecodeLog.logger.info(t.getName()+" 文档数:" + count);
							//System.out.println(doc.get("totalcity"));
							sa.processDocment(doc);
							writer.addDocument(doc);
						}
					}

				} catch (NullPointerException e) {
					e.printStackTrace();
					System.out.println(tempString);
					DataDecodeLog.logger.error(tempString);
				}
			}
			this.AddVersion(writer);
			
			reader.close();
			DataDecodeLog.logger.info("编译数据	"+fileName+":"+count);
			// fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}

  private void AddVersion(IndexWriter writer){
		Document about_doc = new Document();
		java.util.Date now = new java.util.Date(); 

		about_doc.add(new Field("about","tdtsearch",Field.Store.YES,Field.Index.ANALYZED));
		about_doc.add(new Field("dataversion",now.toLocaleString(),Field.Store.YES,Field.Index.ANALYZED));
		about_doc.add(new Field("engineversion",this.engine_version,Field.Store.YES,Field.Index.ANALYZED));
		about_doc.add(new Field("searchversion",this.search_version,Field.Store.YES,Field.Index.ANALYZED));
		
		try {
			writer.addDocument(about_doc);
		} catch (CorruptIndexException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
	public static void main(String[] args) throws Exception {

		
		ArrayList<String> fileList = new ArrayList<String>();

		PoiIndex index = new PoiIndex();
		
		//ndex.PoiIndex config.txt XMLConf_old/poi_index.xml
		//final String CONFIG = "c:\\poi\\config.txt";
		
		//final String OLD_POI_XML="c:\\poi\\XMLConf_old\\landmark.xml";
		
		//args = new String[]{"",""};
		

		try {
			// index.ParseConfig();
			ConfigParse config = new ConfigParse();
			config.ParseConfig(args[0]);
			if(!DataDecodeLog.IsInit())
				DataDecodeLog.initLog(config.SearchLog);

			index.engine_version = config.engine_version;
			
			index.search_version = config.search_version;
			String xmlFile =config.IndexXMLFile;
			String outindex = config.m_GlobalName;
			if(args.length>=2){
				xmlFile =args[1];
			}
			
			
			System.out.println(xmlFile);
			IndexParse parse = new IndexParse();
			HashMap<String, DataIndex> indexs_mo = parse
					.getIndexTable(xmlFile);
			DataDecodeLog.logger.info("全国开始编译");
			for (DataIndex t : indexs_mo.values()) {
				//如果全国索引名称为空
				//String outindex = "";如果参数大于等于2时，导出文件由配置表中name项决定
				if (config.m_GlobalName != null&&args.length<2) {
					outindex = config.m_GlobalName;
				} else {
					outindex = config.IndexPath + t.getIndex_name();
				}
				File indexDir = new File(outindex);
				Analyzer analyzer = null;

				if (t.analyzer == null) {
					analyzer = new IKAnalyzer();
				} else if (t.analyzer.equalsIgnoreCase("IKAnalyzer")) {
					analyzer = new IKAnalyzer();
				} else if (t.analyzer.equalsIgnoreCase("SingleAnalyzer")) {
					analyzer = new SingleAnalyzer();
				} else {
					analyzer = new StandardAnalyzer(Version.LUCENE_31);
				}
				@SuppressWarnings("deprecation")
				IndexWriter writer = new IndexWriter(
						FSDirectory.open(indexDir), analyzer, true,
						IndexWriter.MaxFieldLength.LIMITED);
				writer.setRAMBufferSizeMB(256);
				writer.setMaxMergeDocs(10000);
				writer.setMergeFactor(10000);
			
				
				// 增加元数据1
				for (IndexTable indext : t.getSource()) {
					if (indext.source_suffix != null&&!indext.source_suffix.equalsIgnoreCase("")) {
						String[] start_end = indext.source_suffix.split(",");
						int start = Integer.parseInt(start_end[0]);
						int end = Integer.parseInt(start_end[1]);
						for (int i = start; i <= end; i++) {
							String file_name = indext.source_path + i;
							index.makeTextIndexByConfig(file_name, writer,
									indext, null);
						}
					} else {

						index.makeTextIndexByConfig(indext.source_path, writer,
								indext, null);
					}
				}

				writer.optimize();
				writer.close();
			}
			DataDecodeLog.logger.info("全国结束编译");
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		// TODO Auto-generated method stub

	}


}
