package index;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.apache.lucene.index.IndexWriter;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class DomParse {

	private HashMap<String, String> IndexMap;
	public Set<IndexWriter> Writers;

	//遍历索引分配的配置文仄1�7
	public HashMap<String, String> GetIndexname(String filename) {
		IndexMap = new HashMap<String, String>();
		long lasting = System.currentTimeMillis();
		try {
			File f = new File(filename);
			SAXReader reader = new SAXReader();
			Document doc = reader.read(f);
			Element root = doc.getRootElement();
			//root.c
			Element foo;
			for (Iterator i = root.elementIterator("category"); i.hasNext();) {
				//for (Iterator j = (Element)i.elementIterator("codenum"); j.hasNext();) {
				foo = (Element) i.next();
				String name = foo.element("name").getText();
				System.out.println("index‘s name is＄1�7" + name);
				Element e_adds = foo.element("lists");

				for (Iterator i_adds = e_adds.elementIterator(); i_adds
						.hasNext();) {
					Element e_add = (Element) i_adds.next();
					String list = e_add.getText();

					//		                if(list.length()>4)
					//		                {
					//		                	list = list.substring(0, 4);
					//		                	System.out.println(list);
					//		                }
					System.out.println(list);
					IndexMap.put(list, name);

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("运行时间＄1�7" + (System.currentTimeMillis() - lasting)
				+ " 毫秒");
		return IndexMap;
	}

}
