package index;

import help.HelpSearch;
import help.Pinyin;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Pattern;

import log.DataDecodeLog;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;

import com.tianditu.tools.CreateUUID;

import adminMag.AdminDataMan;

import Util.StringTool;

/**
 * 字段处理类 默认对一个字段的处理函数包括两个参数，第一个参数source,第二个参数arr
 * 默认对一个字段的子域处理包括两个参数，第一个参数source,第二个参数arr 默认对函数过滤类型包括一个参数arr
 * 
 * @author chenxinfeng
 * @since 2012.11.02
 */
public class StringAction {
	// 处理之后的结果
	public static StringAction m_instance;
	public String[] result;
	HashSet<String> dic;
	HashSet<String> adminChange;
	HashMap<String, String> admininfo;
	//HashSet<String> md5test;
	//FileWriter fw = null;

	private StringAction() {
		super();
		// TODO Auto-generated constructor stub
		dic = new HashSet<String>();
		adminChange = new HashSet<String>();
		admininfo = new HashMap<String, String>();
		//md5test = new HashSet<String>();
		/*try {
			fw = new FileWriter("C:/md5test.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		//initAdminInfo();
		//initAdminChange();
	}
	 protected void finalize() {
/*		 try {
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		 System.out.println("data index  over");
	 }
	public static StringAction GetInstance() {
		if (m_instance == null) {
			m_instance = new StringAction();
		}
		return m_instance;
	}

	/**
	 * 初始化行政区详细信息数据
	 * 
	 */
	public void initAdminInfo() {
		String file = "E:\\adminname\\省市简介-20130801.csv";
		FileInputStream fi;
		try {
			fi = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fi, "gbk");// ,
			// "utf-8"
			BufferedReader reader = new BufferedReader(isr);
			String tempString = null;

			while ((tempString = reader.readLine()) != null) {
				String[] arr = tempString.split("\",\"");
				for (int i = 0; i < arr.length; i++) {
					arr[i] = arr[i].replaceAll("\"", "");
				}
				if (arr[6] != null && !arr[6].equalsIgnoreCase(""))
					admininfo.put(arr[0], arr[6]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 初始化行政区信息变更记录
	 * 
	 */
	public void initAdminChange() {
		String file = "E:\\adminname\\change.txt";
		FileInputStream fi;
		try {
			fi = new FileInputStream(file);
			InputStreamReader isr = new InputStreamReader(fi, "gbk");// ,
			// "utf-8"
			BufferedReader reader = new BufferedReader(isr);
			String tempString = null;

			while ((tempString = reader.readLine()) != null) {
				if (!tempString.equalsIgnoreCase("")) {
					adminChange.add("156" + tempString);
				}
				// System.out.println(tempString);
				/*
				 * String[] arr = tempString.split(",");
				 * if(arr.length>20&&arr[10]!=null&&!arr[10].equalsIgnoreCase("")){
				 * adminChange.add("156"+arr[10]); System.out.println(arr[10]); }
				 */
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	/**
	 * 过滤机制for地名专题
	 * citycode不是9位码和是岛屿的结尾去除
	 * @param arr
	 * @return
	 */
	public boolean FilterForAdminName(String[] arr, Document doc, Boolean isLay) {
		//String citycode = arr[2];
		if (arr[0].equalsIgnoreCase("nid")||arr[2].endsWith("0099")||arr[1].endsWith("0099")) {
			return false;
		}
		return true;
	}
	/**
	 * tag处理for poi索引
	 * 
	 * @param source
	 * @return
	 */
	public String parseTag(String source, String[] arr) {
		String tag = source;
		tag = tag.replace("null", "");
		return tag;
	}

	/**
	 * 过滤机制for索引处理
	 * 
	 * @param arr
	 * @return
	 */
	public boolean FilterForPoiIndex(String[] arr, Document doc, Boolean isLay) {
		// 过滤信息特殊处理
		if (arr.length < 11) {
			return false;
		}
		if (isLay && !arr[4].startsWith("156")) {
			//System.out.println("remove:" + arr[4]);
			return false;
		}
		return true;
	}

	/**
	 * 过滤机制for公交busexit
	 * 
	 * @param arr
	 * @return
	 */
	public boolean FilterForBusExit(String[] arr, Document doc, Boolean isLay) {
		// 过滤信息特殊处理
		if (arr[3].equals("0")) {
			return false;
		}
		String lonlat = arr[2];
		String lArr[] = lonlat.split(",");
		if (lArr.length != 2) {
			// //System.out.println("坐标错误");
			return false;
		}
		return true;
	}

	/**
	 * 过滤机制for分级索引
	 * 
	 * @param arr
	 * @return
	 */
	public boolean FilterForLevel(String[] arr, Document doc, Boolean isLay) {
		// 过滤信息特殊处理
		String id = arr[0];
		// 特殊处理
		String citycode = arr[4];
		if (!citycode.startsWith("156")) {
			return false;
		}
		// 特殊处理
		String sid = id + "";
		if (sid.startsWith("2000")) {
			return false;
		}
		return true;
	}

	/**
	 * 过滤机制for提示词处理
	 * citycode不是9位码和是岛屿的结尾去除
	 * @param arr
	 * @return
	 */
	public boolean FilterForCue(String[] arr, Document doc, Boolean isLay) {
		// 过滤信息特殊处理
		String id = arr[2];
		String type = arr[4];
		String sid = id + "";
		if(sid.equalsIgnoreCase("1018371313"))
			System.out.println("1018371313:"+arr.toString());
		if (sid.startsWith("2000")) {
			return false;
		}

		if (!arr[1].startsWith("156")) {
			doc.setBoost(0.1f);
		}
		String citycode = arr[1];
		if (citycode.length() < 9||citycode.endsWith("0099")) {
			//System.out.println("filter for cue:"+arr[0]+" "+arr[1]);
			return false;
		}
		return true;
	}

	/**
	 * 过滤机制for提示词bueexit处理
	 * 
	 * @param arr
	 * @return
	 */
	public boolean FilterForBusExitPrompt(String[] arr, Document doc,
			Boolean isLay) {
		// 过滤信息特殊处理
		if (arr[3].equals("0"))
			return false;

		return true;
	}

	// 增加过滤特殊处理方式
	/**
	 * 过滤某些内容for busline 去除重复的提示词
	 * 
	 * @author chenxinfeng
	 */
	public boolean FilterForBusLinePrompt(String[] arr, Document doc,
			Boolean isLay) {
		String name = arr[1];
		int pos = name.indexOf("(");
		if (pos != -1) {
			name = name.substring(0, pos);
		}

		String citycode = "";
		pos = arr[6].indexOf(" ");
		if (pos != -1) {
			// System.out.println(arr[6] + " " + pos);
			citycode = arr[6].substring(0, pos);
		} else
			citycode = arr[6];

		if (citycode.length() != 6) {
			return false;
		}
		int iCode = Integer.parseInt(citycode);
		int iCodenew = iCode / 100 * 100;
		if (AdminDataMan.IsGBCodeSpecialCityLevel(iCodenew)) {
			citycode = arr[6].substring(0, 2);
			citycode += "0000";
		} else {
			citycode = arr[6].substring(0, 4);
			citycode += "00";

		}

		citycode = "156" + citycode.substring(0, 4) + "00";
		boolean result = dic.contains(name + citycode);
		if (!result) {
			dic.add(name + citycode);
		} else {
			return false;
		}
		return true;
	}
	
	
	
	/**
	 * 在doc处理完毕之后增加额外处理工作
	 * @param doc
	 * @return
	 */
	public boolean processDocment(Document doc){
		
		float bs = (float) 0.5;
		String nameforstore = doc.get("nameforStore");
		String type = doc.get("type");
		
		if(nameforstore.contains("公司")&&type.contains("010000")){
 			float f = doc.getBoost();
			f = f * bs;
			doc.setBoost(f);
		}
		return true;
	}

	/**
	 * 分割字符串为字符数组
	 * 
	 * @param source
	 * @param split
	 * @return
	 */
	public String[] dividetolonandlat(String source, String split) {
		result = source.split(split);
		return result;
	}

	/**
	 * name字段转为name和拼音处理 拼音中特殊字段的处理
	 * 
	 * @param source
	 * @param arr
	 * @return
	 */
	public String[] parseNameAndPinyin(String source, String[] arr) {
		String name = source;
		String nametext = source;
		String[] nas = new String[2];
		nas[0] = name;
		nas[1] = nametext;
		return nas;
	}

	public String[] parseNameAndNameStoreForBusExit(String source, String[] arr) {
		String name = source;
		String nametext = source;
		nametext = StringTool.DoubleByteCharToSingleByteChar(nametext);
		// //System.out.println(nametext);
		name = StringTool.CharStandardization(name);
		String[] nas = new String[2];
		nas[0] = name;
		nas[1] = nametext;
		return nas;
	}

	/**
	 * 行政地名专题 简称和全称
	 * 
	 * @since 2013-05-21
	 * @param source
	 * @param arr
	 * @return
	 */
	public String[] parseNameAndShortNameForAdminName(String source,
			String[] arr) {
		String name = source;
		String nametext = source;
		name = StringTool.CharStandardizationLessChFigureToArabicFigure(name);
		nametext = name.substring(0, name.length() - 1);
		String[] nas = new String[2];
		nas[0] = name;
		nas[1] = nametext;
		return nas;
	}
	
	public String[] parseDocidAndMd5(String source,String[] arr){
		String docid = source;
		String md5 = CreateUUID.getUUID(source.trim());
		String[] docs = new String[2];
		docs[0] = docid;
		docs[1] = md5;
		return docs;
	}

	/**
	 * MD5算法测试是否重复
	 * @param source
	 * @param arr
	 * @return
	 */
	public String[] parseDocidAndMd5Test(String source,String[] arr){
		String docid = source;
		String md5 = CreateUUID.getUUID(source.trim());
		/*if(md5test.contains(md5)){
			System.out.println("docid:"+docid+"repeated!!!!!!!!!!!!!");
			DataDecodeLog.logger.error("docid:"+docid+"repeated!!!!!!!!!!!!!");
		}else{
			md5test.add(md5);
		}*/
/*		try {
			//fw.write(md5+"\r\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		String[] docs = new String[2];
		docs[0] = docid;
		docs[1] = md5;
		return docs;
	}
	
	/**
	 * 拼音处理
	 * 
	 * @param pinyin
	 * @return
	 */
	public String getPinYin(String pinyin, String[] arr) {
		if (pinyin.length() == 0) {
			try {
				pinyin = Pinyin.getPinYin(pinyin);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DataDecodeLog.logger.error(pinyin);
			}
		}
		return pinyin;
	}

	/**
	 * 拼音处理
	 * 
	 * @param pinyin
	 * @return
	 */
	public String getNameForAdmin(String name, String[] arr) {
	
		//System.out.println(name);
		return name;
	}
	/**
	 * 拼音处理 for 提示词
	 * 
	 * @param pinyin
	 * @return
	 */
	public String getPinYinForCueLen(String content, String[] arr) {
		String pinyin = content;
		if (pinyin.length() == 0) {
			try {
				// System.out.println(arr[0]);
				pinyin = Pinyin.getPinYin(arr[0]);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DataDecodeLog.logger.error(arr[0] + "doc_id:" + arr[2]);
			}
		}
		return String.valueOf(pinyin.toLowerCase().length());
	}
	
	/**
	 * 拼音处理 for 提示词
	 * 
	 * @param pinyin
	 * @return
	 */
	public String getPinYinForCue(String content, String[] arr) {
		String pinyin = content;
		if (pinyin.length() == 0) {
			try {
				// System.out.println(arr[0]);
				pinyin = Pinyin.getPinYin(arr[0]);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DataDecodeLog.logger.error(arr[0] + "doc_id:" + arr[2]);
			}
		}
		return pinyin.toLowerCase();
	}

	/**
	 * 通过citycode和类型产生Location和totalcity for busline
	 * 
	 * @param content
	 *            编码
	 * @param arr
	 *            条目中所有信息
	 * @param Db
	 *            提示词类
	 * @return Location和totalcity
	 */
	public String[] parseLocationAndTotalcityForBusLine(String content,
			String[] arr, HelpSearch Db) {
		String name = arr[1];
		int pos = name.indexOf("(");
		if (pos != -1) {
			name = name.substring(0, pos);
		}

		String citycode = "";
		pos = arr[6].indexOf(" ");
		if (pos != -1) {
			citycode = arr[6].substring(0, pos);
		} else
			citycode = arr[6];

		String location = "";
		int iCode = Integer.parseInt(citycode);
		int iCodenew = iCode / 100 * 100;
		if (AdminDataMan.IsGBCodeSpecialCityLevel(iCodenew)) {
			citycode = arr[6].substring(0, 2);
			citycode += "0000";
			// location = Db.codeMap.get(citycode);
		} else {
			citycode = arr[6].substring(0, 4);
			citycode += "00";

		}
		location = Db.codeMap.get("156" + citycode);
		// //System.out.println(location);
		if (location != null)
			location = location.replace("亚洲中国", "");
		else
			location = "";
		citycode = citycode.substring(0, 4) + "00";

		String citytype = "";
		citytype = this.GetTotalCity(citycode);
		// 品组 城市编码
		/*
		 * if (!citycode.startsWith("99") && citycode != "" &&
		 * !citycode.endsWith("00")) { citytype = "990239"; // String citytype =
		 * "990239"; citytype += " "; // citytype += citycode; // citytype += " ";
		 * citytype += citycode.substring(0, 4); citytype += "00"; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } // 处理以00
		 * 或者0000结尾的的 else if (!citycode.startsWith("99") &&
		 * citycode.endsWith("00")) { citytype = "990239 "; if
		 * (citycode.endsWith("0000")) { citytype += citycode; } else if
		 * (citycode.endsWith("00")) { citytype += citycode; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } } else {
		 * citytype = citycode; }
		 */
		String[] nas = new String[2];
		nas[0] = location;
		nas[1] = citytype;
		return nas;
	}

	/**
	 * 通过citycode和类型产生Location和totalcity
	 * 
	 * @param content
	 *            编码
	 * @param arr
	 *            条目中所有信息
	 * @param Db
	 *            提示词类
	 * @return Location和totalcity
	 */
	public String[] parseLocationAndTotalcityForBus(String content,
			String[] arr, HelpSearch Db) {

		String citycode = "156" + content;

		String location = Db.codeMap.get(citycode);
		// //System.out.println(location);
		if (location != null)
			location = location.replace("亚洲中国", "");
		else
			location = "";
		// //System.out.println(location);

		String citytype = "";
		citytype = this.GetTotalCity(citycode);
		// 品组 城市编码
		/*
		 * if (!citycode.startsWith("99") && citycode != "" &&
		 * !citycode.endsWith("00")) { citytype = "990239"; // String citytype =
		 * "990239"; citytype += " "; citytype += citycode; citytype += " ";
		 * citytype += citycode.substring(0, 4); citytype += "00"; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } // 处理以00
		 * 或者0000结尾的的 else if (!citycode.startsWith("99") &&
		 * citycode.endsWith("00")) { citytype = "990239"; citytype += " "; if
		 * (citycode.endsWith("0000")) { citytype += citycode; } else if
		 * (citycode.endsWith("00")) { citytype += citycode; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } } else {
		 * citytype = citycode; }
		 */

		String[] nas = new String[2];
		nas[0] = location;
		nas[1] = citytype;
		return nas;
	}

	/**
	 * 通过citycode和类型产生Location和totalcity
	 * 
	 * @param content
	 *            编码
	 * @param arr
	 *            条目中所有信息
	 * @param Db
	 *            提示词类
	 * @return Location和totalcity
	 */
	public String[] parseLocationAndTotalcityForBusExit(String content,
			String[] arr, HelpSearch Db) {

		String citycode = content;
		String type = arr[4];
		String sixBitCode = citycode;
		/*
		 * if (sixBitCode.length() == 9) { sixBitCode = sixBitCode.substring(3,
		 * 9); }
		 */
		String location = Db.codeMap.get("156" + sixBitCode);
		if (location != null)
			location = location.replace("亚洲中国", "");
		else
			location = "";
		if (type.equals("140105") || type.equals("140104")
				|| type.equals("140106")) {
			int index = location.indexOf(arr[0]);
			if (index != -1) {
				location = location.substring(0, index);
			}

		} else if (type.equals("140103") && !citycode.startsWith("99")) {
			int index = location.indexOf(arr[0]);
			if (index != -1) {
				location = location.substring(0, index);
			}

		}

		String citytype = "";
		// 品组 城市编码
		/*
		 * if (!citycode.startsWith("99") || citycode != "" ||
		 * !citycode.endsWith("00")) { citytype = "990239"; // String citytype =
		 * "990239"; citytype += " "; citytype += citycode; citytype += " ";
		 * citytype += citycode.substring(0, 4); citytype += "00"; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } // 处理以00
		 * 或者0000结尾的的 else if (!citycode.startsWith("99") &&
		 * citycode.endsWith("00")) { citytype = "990239"; if
		 * (citycode.endsWith("0000")) { citytype += citycode; } if
		 * (citycode.endsWith("00")) { citytype += citycode; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } } else {
		 * citytype = citycode; } ;
		 */
		citytype = this.getTotalCity(citycode, arr);
		if ((type.equals("140105") || type.equals("140104"))
				&& arr[1].startsWith("156")) {
			citytype += " 000";
		}
		;

		String[] nas = new String[2];
		nas[0] = location;
		nas[1] = citytype;
		return nas;
	}

	/**
	 * 通过citycode和类型产生Location和totalcity
	 * 
	 * @param content
	 *            编码
	 * @param arr
	 *            条目中所有信息
	 * @param Db
	 *            提示词类
	 * @return Location和totalcity
	 */
	public String[] parseLocationAndTotalcity(String content, String[] arr,
			HelpSearch Db) {

		String citycode = content;
		String type = arr[4];
		String sixBitCode = citycode;
		/*
		 * if (sixBitCode.length() == 9) { sixBitCode = sixBitCode.substring(3,
		 * 9); }
		 */
		String location = Db.codeMap.get(sixBitCode);
		if (location != null)
			location = location.replace("亚洲中国", "");
		else
			location = "";
		if (type.equals("140105") || type.equals("140104")
				|| type.equals("140106")) {
			int index = location.indexOf(arr[0]);
			if (index != -1) {
				location = location.substring(0, index);
			}

		} else if (type.equals("140103") && !citycode.startsWith("99")) {
			int index = location.indexOf(arr[0]);
			if (index != -1) {
				location = location.substring(0, index);
			}

		}

		String citytype = "";
		// 品组 城市编码
		/*
		 * if (!citycode.startsWith("99") || citycode != "" ||
		 * !citycode.endsWith("00")) { citytype = "990239"; // String citytype =
		 * "990239"; citytype += " "; citytype += citycode; citytype += " ";
		 * citytype += citycode.substring(0, 4); citytype += "00"; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } // 处理以00
		 * 或者0000结尾的的 else if (!citycode.startsWith("99") &&
		 * citycode.endsWith("00")) { citytype = "990239"; if
		 * (citycode.endsWith("0000")) { citytype += citycode; } if
		 * (citycode.endsWith("00")) { citytype += citycode; citytype += " ";
		 * citytype += citycode.substring(0, 2); citytype += "0000"; } } else {
		 * citytype = citycode; } ;
		 */
		citytype = this.getTotalCity(citycode, arr);
		if ((type.equals("140105") || type.equals("140103") ||type.equals("140106")|| type
				.equals("140104"))
				&& arr[1].startsWith("156")) {
			citytype += " 000";
		}
		;

		String[] nas = new String[2];
		nas[0] = location;
		nas[1] = citytype;
		return nas;
	}

	/**
	 * busline的name和nameforstore的特殊处理
	 * 
	 * 
	 * @param content
	 * @return
	 */
	public String[] parseNameAndNameStoreForBusLine(String content, String[] arr) {
		String name = content;
		// //System.out.println(name);

		String nametext = content;
		nametext = StringTool.DoubleByteCharToSingleByteChar(nametext);
		// //System.out.println(nametext);
		name = StringTool.CharStandardization(name);
		int index1 = name.indexOf("(");
		name = name.substring(0, index1);

		String[] nas = new String[2];
		nas[0] = name;
		nas[1] = nametext;
		return nas;
	}

	// 判断字符串是否为空
	public boolean IsEnglish(String strRecord) {
		int length = strRecord.length();

		for (int i = 0; i < length - 1; i++) {
			char c = strRecord.charAt(i);
			if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' '
					|| (c >= '0' && c <= '9') || c == '*') {
				//continue;
				return true;
			} else {
				 continue;
			}
		}
		return false;
	}
	/**
	 * Name处理方式For地标
	 * 
	 * @since 2013-2-25
	 * @param content
	 * @return 返回数组包含4项分别是name,oldname,othername,abbreviation,nameforStore
	 */
	public String[] parseNameAndNameStoreForLandmark(String content,
			String[] arr) {
		String name = content;

		name = name.replaceAll("\\(旧\\)", "");
		boolean flg = IsEnglish(name);
		if (!flg)
			name = name.replaceAll(" ", "");
		else
			;

		// String[] names = name.split("***");
		String[] names = Pattern.compile("(\\*\\*\\*)|\\|").split(name);
		name = name.replace("***", " ");
		name = name.replace("|", " ");
		name = name.trim();
		String nametext = name;
		if (!name.equalsIgnoreCase("")) {
			name = StringTool.CharStandardization(name);
		}

		boolean flag = check(nametext);
		if (!flag) {

			int length = nametext.indexOf(" ");
			if (length > 0) {
				// fw.write(nametext + "\n");
				// ////System.out.println(nametext);
				nametext = nametext.substring(0, length);
			}
		}
		String[] nas = new String[5];
		nas[0] = name;
		nas[1] = "";
		nas[2] = "";
		nas[3] = "";

		if (names.length > 1) {
			for (int i=1,j = 1; j < names.length; j++) {
				if(!names[j].equalsIgnoreCase("")){
					String temp = names[j];
					//System.out.println(temp);
					if(i<5){
						nas[i++] = temp;
					}else{
						DataDecodeLog.logger.error("content:"+content);
					}
				}	
			}
		}

		nas[4] = nametext;
		return nas;
	}

	
	/**
	 * 普通poi,name处理方式
	 * 
	 * @param content
	 * @return
	 */
	public String[] parseNameAndNameStore(String content, String[] arr) {
		String name = content;

		/*
		 * name = name.replaceAll("\\(旧\\)", ""); name = name.replaceAll(" ",
		 * ""); name = name.replace("***", " "); name = name.trim(); //
		 * //System.out.println(name); String nametext = name; name =
		 * StringTool.CharStandardization(name); // doc.add(new Field("name",
		 * name, stored_conf, // indexed_conf));
		 */
		int text_length = name.indexOf("***");
		String nametext = name.substring(0,text_length);
		name = name.replaceAll("\\(旧\\)", "");
		boolean flg = IsEnglish(name);
		if (!flg)
			name = name.replaceAll(" ", "");
		else
			;

		name = name.replace("***", " ");
		name = name.trim();
		//String nametext = name;
		if (!name.equalsIgnoreCase("")) {
			name = StringTool.CharStandardization(name);
		}

		
		/*boolean flag = check(nametext);
		if (!flag) {

			int length = nametext.indexOf(" ");
			if (length > 0) {
				// fw.write(nametext + "\n");
				// ////System.out.println(nametext);
				nametext = nametext.substring(0, length);
			}
		}*/
		// ////System.out.println(name);
		/*
		 * String nametext = name; name = StringTool.CharStandardization(name);
		 * 
		 * boolean flag = check(nametext); if (!flag) {
		 * 
		 * int length = nametext.indexOf(" "); if (length > 0) { nametext =
		 * nametext.substring(0, length); } }
		 */
		String[] nas = new String[2];
		nas[0] = name;
		nas[1] = nametext;
		return nas;
	}

	/**
	 * 提示词的name和nameforstore的特殊处理
	 * 
	 * 
	 * @param content
	 * @return
	 */
	public String[] parseNameAndNameStoreForCue(String content, String[] arr) {
		String name = content;
		String nametext = content;

		name = name.replace(" ", "");

		name = StringTool.CharStandardizationLessChFigureToArabicFigure(name);
		String[] nas = new String[2];
		nas[0] = name;
		nas[1] = nametext;
		return nas;
	}

	/**
	 * 普通address处理方式
	 * 
	 * @param content
	 * @return
	 */
	public String[] parseAddressAndAddressStore(String content, String[] arr) {
		String address = content;
		if (address.equals("null")) {
			address = "";
		}

		String addresstext = address;
		address = StringTool.CharStandardization(address);
		String[] nas = new String[2];
		nas[0] = address;
		nas[1] = addresstext;
		return nas;
	}

	/**
	 * 普通电话处理方式
	 * 
	 * @param content
	 * @return
	 */
	public String[] parsePhoneAndPhoneStore(String content, String[] arr) {
		String tel = content;

		if (tel.equals("null")) {
			tel = "";
			content = "";
		} else {
			tel = tel.replace("\"", "");
			int index = tel.indexOf("-");
			String tmp = tel.substring(index + 1);
			tel += " ";
			tel += tmp;
			tel = tel.replace("-", "");

		}

		content = content.replaceAll("\"", "");
		String[] nas = new String[2];
		nas[0] = tel;
		nas[1] = content;
		return nas;
	}

	/**
	 * 公交bus_line 提示词 name处理
	 * 
	 * @param source
	 * @param arr
	 * @return
	 */
	public String[] parseNameForBusLinePrompt(String source, String[] arr) {
		String name = arr[1];
		int pos = name.indexOf("(");
		if (pos != -1) {
			name = name.substring(0, pos);
		}

		String pinyin = null;
		if (pinyin == null) {
			try {
				pinyin = Pinyin.getPinYin(name);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DataDecodeLog.logger.error(name);
			}
		}

		String[] nas = new String[3];
		nas[0] = name;
		nas[0] = StringTool
				.CharStandardizationLessChFigureToArabicFigure(nas[0]);
		nas[1] = name;
		nas[2] = pinyin.toLowerCase();
		return nas;
	}

	/**
	 * 公交bus_line 提示词 name处理
	 * 
	 * @param source
	 * @param arr
	 * @return
	 */
	public String[] parseNameForBusExitPrompt(String source, String[] arr) {
		String name = source;
		String pinyin = null;
		if (pinyin == null) {
			try {
				pinyin = Pinyin.getPinYin(name);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DataDecodeLog.logger.error(name);
			}
		}
		String[] nas = new String[3];
		nas[0] = name;
		nas[0] = StringTool
				.CharStandardizationLessChFigureToArabicFigure(nas[0]);
		nas[1] = name;
		nas[2] = pinyin.toLowerCase();
		return nas;
	}

	/**
	 * 公交bus unionstop 提示词 name处理
	 * 
	 * @param source
	 * @param arr
	 * @return
	 */
	public String[] parseNameForBusPrompt(String source, String[] arr) {

		String name = source;
		int poi = name.indexOf("公交站");

		String nametext = "";
		if (poi == -1) {
			int pos = arr[1].indexOf("站");
			if (pos == -1 && arr[4].equals("0")) {
				nametext += name;
				nametext += "-公交站";
			}

			else if (pos == -1 && arr[4].equals("1")) {
				nametext += name;
				nametext += "-地铁站";
			} else if (pos != -1 && arr[4].equals("1")) {
				nametext = name.substring(0, name.length() - 1);
				nametext += "-地铁站";
			} else if (pos != -1 && arr[4].equals("0")) {
				nametext += name;
				nametext += "-公交站";
			}
		} else
			nametext = name;

		String pinyin = null;
		if (pinyin == null) {
			try {
				pinyin = Pinyin.getPinYin(name);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				DataDecodeLog.logger.error(name);
			}
		}

		String pylen = String.valueOf(pinyin.toLowerCase().length());
		String[] nas = new String[4];
		nas[0] = nametext;
		nas[0] = StringTool
				.CharStandardizationLessChFigureToArabicFigure(nas[0]);
		nas[1] = nametext;
		nas[2] = pinyin.toLowerCase();
		nas[3] = pylen;
		return nas;
	}

	/**
	 * 公交名处理方式
	 * 
	 * @param source
	 * @return
	 */
	public String[] parseNameAndNameStoreForBus(String source, Document doc,
			String[] arr) {
		String name = source;
		if (arr[4].equals("0")) {
			if (name.endsWith("公交站"))
				name = name.substring(0, name.length() - 3);
		} else if (arr[4].equals("1")) {
			if (name.endsWith("地铁站")) {
				// 去掉地铁站
				name = name.substring(0, name.length() - 3);
			} else if (name.endsWith("站") && name.length() > 2) {
				// 去掉站字
				name = name.substring(0, name.length() - 1);
			}
		}

		String nametext = name;
		if (arr[4].equals("0")) {
			nametext += "-公交站";
		} else if (arr[4].equals("1")) {
			nametext += "-地铁站";
			;
		}

		nametext = StringTool.DoubleByteCharToSingleByteChar(nametext);
		name = StringTool.CharStandardization(name);

		String[] nas = new String[2];
		nas[0] = name;
		nas[1] = nametext;
		return nas;
	}

	/**
	 * 字符串转为lon或者lat的形式
	 * 
	 * @param content
	 * @return
	 */
	public String parsetoLonLat(String content, String[] arr) {
		long ilon = (int) (Float.parseFloat(content) * 1000000);
		content = ilon + "";
		return content;
	}

	/**
	 * 字符串转为lon或者lat的形式
	 * 
	 * @param content
	 * @return
	 */
	public String parsetoLonLatForBus(String content, String[] arr) {
		// long ilon = (int) (Float.parseFloat(content) * 1000000);
		long ilon = (long) (Double.parseDouble(content) * 1000000);
		content = ilon + "";
		return content;
	}

	public String getTotalCityForPoiIndex(String source, String[] arr) {
		String citycode = source;
		String citytype = "";
		if (!arr[11].equals("null")) {
			citytype = getTotalCity(arr[11], arr);
			citytype += " ";
			citytype += getTotalCity(citycode, arr);
		} else
			citytype += getTotalCity(citycode, arr);

		return citytype;

	}
	/**
	 * 获得详细信息
	 * @param citycode
	 * @param arr
	 * @return
	 */
	public String getAdminInfo(String docid, String[] arr) {

		/*if(citycode.equalsIgnoreCase("156220000")){
			System.out.println("jilin");
		}
		String citycodes = getTotalCityForAdminName(citycode, arr).trim();
		String[] codes = citycodes.split(" ");*/
		String info = admininfo.get(docid);
		if (info == null)
			info = "";
		return info;
	}

	public String getAdminChange(String citycode, String[] arr) {
		String citycodes = getTotalCityForAdminName(citycode, arr);
		String[] codes = citycodes.split(" ");
		if (adminChange.contains(codes[codes.length - 1])) {
			return "true";
		} else {
			return "false";
		}
	}
	
	/**
	 *  是否是特殊区县级行政区（等同于省级的区县：中沙、南沙、西沙）
	 * @param iCode
	 * @return 
	 */
	public static boolean IsGBCodeSpecialCountyLevel(int iGBCode){
		switch(iGBCode){
		  case 156419001:
		  case 156429004:
		  case 156429005:
		  case 156429006:
		  case 156429021:
		  case 156460301:
		  case 156460302:
		  case 156460303:
		  case 156469001:
		  case 156469002:
		  case 156469003:
		  case 156469005:
		  case 156469006:
		  case 156469007:
		  case 156469021:
		  case 156469022:
		  case 156469023:
		  case 156469024:
		  case 156469025:
		  case 156469026:
		  case 156469027:
		  case 156469028:
		  case 156469029:
		  case 156469030:
		  case 156659001:
		  case 156659002:
		  case 156659003:
		  case 156659004:
		  case 156659005:
		  case 156659006:
		  // 台湾的区县及市
		  case 156710009:
		  case 156710003:
		  case 156710004:
		  case 156710005:
		  case 156710006:
		  case 156710007:
		  case 156710008:
		  case 156710001:
		  case 156710010:
		  case 156710011:
		  case 156710012:
		  case 156710013:
		  case 156710014:
		  case 156710016:
		  case 156710018:
		  case 156710019:
		  case 156710020:
		  case 156710021:
		  case 156710022:
		  case 156710023:
		  // 香港区县码
		  case 156810101:
		  case 156810102:
		  case 156810103:
		  case 156810104:
		  case 156810105:
		  case 156810106:
		  case 156810107:
		  case 156810108:
		  case 156810109:
		  case 156810110:
		  case 156810111:
		  case 156810112:
		  case 156810113:
		  case 156810114:
		  case 156810115:
		  case 156810116:
		  case 156810117:
		  case 156810118:
		  // 澳门行政区
		  case 156820001:
		  case 156820002:
		  case 156820003:
		  case 156820004:
		  case 156820005:
		  case 156820006:
		  case 156820007:
		  case 156820008:
			{
				return true;
			}
		}
	
		return false;
	}

	/**
	 * 行政地名专题搜索行政区码 根据arr[3]类别信息 国家级去前三位 省级取前5为 市级取前7位
	 * 
	 * @param citycode
	 * @return
	 */
	public String getTotalCityForAdminName(String citycode, String[] arr) {
		String result = "";
		String type = arr[3];


		if (citycode.length() != 9) {
			// //System.out.println("输入的长度不对");
			return result;
		}

		if (type.equals("140102")) {
			String country = citycode.substring(0, 3);
			country += "000000 ";
			result += country;
		} else if (type.equals("140103") || type.equals("140104")
				|| type.equals("140106")) {

			String country = citycode.substring(0, 3);
			country += "000000 ";
			result += country;

			String province = citycode.substring(0, 5);
			province += "0000 ";
			result += province;
		} else if (type.equals("140105") || type.equals("140107")) {

			String country = citycode.substring(0, 3);
			country += "000000 ";
			result += country;

			String province = citycode.substring(0, 5);
			province += "0000 ";
			result += province;

			// 添加市级编码
			String city = citycode.substring(0, 7);
			city += "00 ";
			if (!province.equals(city)) {
				result += city;
			}
		} else //if (type.equals("140108") || type.equals("140109")) {
		{
			String country = citycode.substring(0, 3);
			country += "000000 ";
			result += country;

			// 添加省级编码
			String province = citycode.substring(0, 5);
			province += "0000 ";
			result += province;
			// 添加市级编码
			String city = citycode.substring(0, 7);
			city += "00 ";
			if (!province.equals(city)) {
				result += city;
			}
			// 添加县级编码
			city = city.trim();
			if (!city.equals(citycode)) {
				result += citycode;
			}
		}

		return result;
	}

	/**
	 * 原6位码处理方式
	 * 
	 * @param citycode
	 * @param arr
	 * @return
	 */
	public String getTotalCityForSixBitCode(String citycode, String[] arr) {
		String result = "";

		// 国际编码
		if (citycode.startsWith("99")) {
			result = citycode;
			return result;
		}

		if (citycode.length() != 6) {
			// //System.out.println("输入的长度不对");
			return result;
		}

		result += "990239 ";

		// 添加省份编码
		String province = citycode.substring(0, 2);
		province += "0000 ";
		result += province;

		// 添加市级编码
		String city = citycode.substring(0, 4);
		city += "00 ";
		if (!province.equals(city)) {
			result += city;
		}

		// 添加县级编码
		city = city.trim();
		if (!city.equals(citycode)) {
			result += citycode;
		}

		return result;
	}

	/**
	 * 城市编码设置 变更为9位码
	 * 
	 * @author chenxinfeng
	 * @param citycode
	 * @return
	 */
	public String getTotalCity(String citycode, String[] arr) {
		if (citycode.length() == 6) {
			// return getTotalCityForSixBitCode(citycode,arr);
			citycode = "156" + citycode;
		}
		String result = "";
		if (citycode.length() != 9) {
			return result;
		}
		String country = citycode.substring(0, 3);
		country += "000000 ";
		result += country;
		if (citycode.endsWith("000000"))
			return result;

		// 添加省份编码
		String province = citycode.substring(0, 5);
		province += "0000 ";
		result += province;

		if (citycode.endsWith("0000"))
			return result;

		// 添加市级编码
		String city = citycode.substring(0, 7);
		city += "00 ";
		if (!province.equals(city)) {
			result += city;
		}

		if (citycode.endsWith("00"))
			return result;

		// 添加县级编码
		city = city.trim();
		if (!city.equals(citycode)) {
			result += citycode;
		}

		return result;
	}

	/**
	 * 城市编码转换
	 * 
	 * @param citycode
	 * @return
	 */
	public String GetTotalCity(String citycode) {
		return getTotalCity(citycode, null);
	}

	/**
	 * 公交line citycode处理方式 最新，包含一条拆为多条 将wirter更改为writers,方便分级索引使用
	 * 
	 * @param content
	 * @return 返回true表示忽略一下的处理
	 * @throws IOException
	 * @throws CorruptIndexException
	 */
	public boolean getTotalCityForNewBusLine(String content, String[] arr,
			Document doc, IndexWriter[] writers) throws CorruptIndexException,
			IOException {
		String citycode = arr[6];
		IndexWriter writer = null;
		IndexWriter writer2 = null;
		if (writers.length > 1) {
			writer = writers[0];
			writer2 = writers[1];
		} else {
			writer = writers[0];
			writer2 = writers[0];
		}

		doc
				.add(new Field("stationnum", arr[7], Field.Store.YES,
						Field.Index.NO));

		String[] code = citycode.split(" ");

		int bCode = Integer.parseInt(code[0]);
		int eCode = Integer.parseInt(code[code.length - 1]);
		if (bCode == eCode || eCode == 0) {
			String citytype = GetTotalCity(code[0]);
			doc.add(new Field("totalcity", citytype, Field.Store.YES,
					Field.Index.ANALYZED));

			float f = doc.getBoost();
			f = f * 10f;
			doc.setBoost(f);
			writer.addDocument(doc);
		} else {
			if (!writer2.equals(writer)) {
				String citytype = GetTotalCity(code[0]);
				doc.add(new Field("totalcity", citytype, Field.Store.YES,
						Field.Index.ANALYZED));

				float f = doc.getBoost();
				f = f * 10f;
				doc.setBoost(f);
				writer.addDocument(doc);

				doc.removeField("totalcity");
				citytype = GetTotalCity(code[code.length - 1]);
				doc.add(new Field("totalcity", citytype, Field.Store.YES,
						Field.Index.ANALYZED));
				writer2.addDocument(doc);
			} else {
				String citytype = GetTotalCity(code[0]);
				citytype += " " + GetTotalCity(code[code.length - 1]);
				doc.add(new Field("totalcity", citytype, Field.Store.YES,
						Field.Index.ANALYZED));

				float f = doc.getBoost();
				f = f * 10f;
				doc.setBoost(f);
				writer.addDocument(doc);
			}
		}

		return true;
	}

	/**
	 * 公交line citycode处理方式
	 * 
	 * @param content
	 * @return
	 */
	public String getTotalCityForBusLine(String content, String[] arr) {
		String citycode = content;
		int pos = citycode.indexOf(" ");
		if (pos > -1) {
			citycode = citycode.substring(0, pos);
		}
		String citytype = new String();// "990239";
		if (citycode == null) {
			citytype = "";
		}
		citytype = this.getTotalCity(citycode, arr);
		return citycode;
	}

	/**
	 * 公交line citycode处理方式
	 * 
	 * @param content
	 * @return
	 */
	public String getTotalCityForBusExit(String content, String[] arr) {
		String citycode = content;
		// int pos = citycode.indexOf(" ");
		// citycode = citycode.substring(0, pos);

		String citytype = new String();// "990239";
		if (citycode == null) {
			citytype = "";
		}
		citytype = GetTotalCity(citycode);
		return citytype;
	}

	/**
	 * type类特别处理
	 * 
	 * @param content
	 * @return
	 */
	public String getTypeForBus(String content, String[] arr) {
		String type = "";
		if (content.equals("0")) {
			type = "120702";
		} else if (content.equals("1")) {
			type = "120400";
		} else {
			type = "998877";
		}

		String typelist = TrimZero(type);
		if (typelist.length() == 6) {
			typelist += " ";
			typelist += type.substring(0, 4);
			typelist += "00";
			typelist += " ";
			typelist += type.substring(0, 2);
			typelist += "0000";

		} else if (typelist.length() == 4) {
			typelist += "00 ";
			typelist += type.substring(0, 2);
			typelist += "0000";
		} else {
			typelist = type;
		}
		return typelist;
	}

	/**
	 * type类特别处理 For 行政地名搜索
	 * 
	 * @param content
	 * @return
	 */
	public String getTypeForAdmin(String content, String[] arr) {
		String type = content;
		// 台北特殊处理
		if (arr[0].equalsIgnoreCase("1024175041")) {
			content = "140108";
			System.out.println("台北特殊处理，使其citycode与type的编码规则一致");
		}
		
		if(IsGBCodeSpecialCountyLevel(Integer.parseInt(arr[2]))&&content.equalsIgnoreCase("140108")){
			content = "140120";
			System.out.println("省直辖县："+arr[2]);
		}

		String typelist = TrimZero(content);
		if (typelist.length() == 6) {
			typelist += " ";
			typelist += type.substring(0, 4);
			typelist += "00";
			typelist += " ";
			typelist += type.substring(0, 2);
			typelist += "0000";

		} else if (typelist.length() == 4) {
			typelist += "00 ";
			typelist += type.substring(0, 2);
			typelist += "0000";
		} else {
			typelist = type;
		}
		// 增加备用分类
		String typelist_alternate = "";
		if (arr.length >= 15 && !arr[14].equalsIgnoreCase("null")
				&& !arr[14].equalsIgnoreCase("")) {
			String type_alternate = arr[14];
			typelist_alternate = TrimZero(arr[14]);
			if (typelist_alternate.length() == 6) {
				typelist_alternate += " ";
				typelist_alternate += type_alternate.substring(0, 4);
				typelist_alternate += "00";
				typelist_alternate += " ";
				typelist_alternate += type_alternate.substring(0, 2);
				typelist_alternate += "0000";

			} else if (typelist_alternate.length() == 4) {
				typelist_alternate += "00 ";
				typelist_alternate += type_alternate.substring(0, 2);
				typelist_alternate += "0000";
			} else {
				typelist_alternate = type_alternate;
			}
		}
		if (typelist_alternate.equalsIgnoreCase("")) {
			return typelist;
		} else {
			return typelist + " " + typelist_alternate;
		}
	}
	 /* type类特别处理
	 * 
	 * @param content
	 * @return
	 */
	public String getType(String content, String[] arr) {
		String type = content;
		String typelist = TrimZero(content);
		if (typelist.length() == 6) {
			typelist += " ";
			typelist += type.substring(0, 4);
			typelist += "00";
			typelist += " ";
			typelist += type.substring(0, 2);
			typelist += "0000";

		} else if (typelist.length() == 4) {
			typelist += "00 ";
			typelist += type.substring(0, 2);
			typelist += "0000";
		} else {
			typelist = type;
		}
		// 增加备用分类
		String typelist_alternate = "";
		if (arr.length >= 15 && !arr[14].equalsIgnoreCase("null")
				&& !arr[14].equalsIgnoreCase("")) {
			String type_alternate = arr[14];
			typelist_alternate = TrimZero(arr[14]);
			if (typelist_alternate.length() == 6) {
				typelist_alternate += " ";
				typelist_alternate += type_alternate.substring(0, 4);
				typelist_alternate += "00";
				typelist_alternate += " ";
				typelist_alternate += type_alternate.substring(0, 2);
				typelist_alternate += "0000";

			} else if (typelist_alternate.length() == 4) {
				typelist_alternate += "00 ";
				typelist_alternate += type_alternate.substring(0, 2);
				typelist_alternate += "0000";
			} else {
				typelist_alternate = type_alternate;
			}
		}
		if (typelist_alternate.equalsIgnoreCase("")) {
			return typelist;
		} else {
			return typelist + " " + typelist_alternate;
		}
	}

	// 去除后边空格
	private String TrimZero(String word) {
		String result = null;

		if (word.endsWith("0000"))
			result = word.substring(0, 2);
		else if (word.endsWith("00"))
			result = word.substring(0, 4);
		else
			result = word;

		return result;
	}

	/**
	 * 
	 * @param content
	 * @return
	 */
	public String DoubleByteCharToSingleByteChar(String content, String[] arr) {
		return StringTool.DoubleByteCharToSingleByteChar(content).trim();
	}

	/**
	 * 公交citycode处理方式
	 * 
	 * @param citycode
	 * @return
	 */
	public String getTotalCityForBus(String citycode, String[] arr) {
		return this.getTotalCity(citycode, arr);
		// citycode = content;
		/*
		 * String citytype = new String();// "990239"; if (citycode == null) {
		 * citytype = ""; } // 拼组 城市编码 if (!citycode.startsWith("99") ||
		 * citycode != "" || !citycode.endsWith("00")) { citytype = "990239"; //
		 * String citytype = "990239"; citytype += " "; citytype +=
		 * citycode.substring(0, 2); citytype += "0000";
		 * 
		 * citytype += " "; citytype += citycode.substring(0, 4); citytype +=
		 * "00"; citytype += " "; citytype += citycode; } // 处理以00 或者0000结尾的的
		 * else if (!citycode.startsWith("99") && citycode.endsWith("00")) {
		 * citytype = "990239"; if (citycode.endsWith("0000")) { citytype +=
		 * citycode; } if (citycode.endsWith("00")) { citytype +=
		 * citycode.substring(0, 2); citytype += "0000";
		 * 
		 * citytype += " "; citytype += citycode; } } else { citytype =
		 * citycode; } return citytype;
		 */
	}

	private boolean check(String fstrData) {
		char c = fstrData.charAt(0);
		if (((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) throws IOException {
		System.out.println("Hello world");
		StringAction action = new StringAction();
		action.parseNameAndNameStore("酒乐go NO.5*********", null);
	}
}
