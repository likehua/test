package index;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import log.DataDecodeLog;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.FSDirectory;
import org.wltea.analyzer.lucene.IKAnalyzer;

import com.tianditu.search.config.DataIndex;
import com.tianditu.search.config.IndexParse;
import com.tianditu.search.config.IndexTable;

import Util.StringTool;

public class LayIndex {

	public HashMap<String, IndexWriter> ID_map = null;
	public HashMap<String, String> list = null;

	Map<String, String> typeMap = new HashMap<String, String>();

	public void InitIndex(HashMap<String, String> mapLlist, String canshu,DataIndex t)
			throws Exception {
		ConfigParse config = new ConfigParse();
		config.ParseConfig(canshu);
		IKAnalyzer analyzer = new IKAnalyzer();
		//StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_31);
		HashSet<String> sset = new HashSet<String>();
		ID_map = new HashMap<String, IndexWriter>();

		try {
			Iterator iter = mapLlist.keySet().iterator();

			while (iter.hasNext()) {

				String key = (String) iter.next();

				String val = (String) mapLlist.get(key);
				System.out.println("key:" + key + "	value =:" + val);
				sset.add(val);
			}

			Iterator iter1 = sset.iterator();
			while (iter1.hasNext()) {

				String key = (String) iter1.next();
				System.out.println(key);
				//File indexDir = new File(config.m_LevelName + key);
				File indexDir = new File(config.IndexPath + t.getIndex_name()+"_LevelIndex"+"/"+key);
				IndexWriter writer1 = new IndexWriter(FSDirectory
						.open(indexDir), analyzer, true,
						IndexWriter.MaxFieldLength.LIMITED);
				//writer1.setRAMBufferSizeMB(64);
				writer1.setMaxMergeDocs(5000);
				// 内存中存傄1�7�1�7�文档时写成磁盘丄1�7�1�7�块
				writer1.setMergeFactor(5000);
				writer1.setRAMBufferSizeMB(64);
				writer1.setUseCompoundFile(true);

				ID_map.put(key, writer1);
			}
			System.out.print(ID_map.size());
		} catch (Exception e) {

			e.printStackTrace();
			// TODO: handle exception
		}

	}

	public void UnIndex() throws CorruptIndexException, IOException {
		Iterator iter = ID_map.keySet().iterator();

		while (iter.hasNext()) {

			String key = (String) iter.next();

			IndexWriter val = (IndexWriter) ID_map.get(key);
			val.optimize();
			val.close();

		}

	}

	public static void main(String[] args) {
		ArrayList<String> fileList = new ArrayList<String>();
		PoiIndex poi_index = new PoiIndex();
		try {

			ConfigParse config = new ConfigParse();
			config.ParseConfig(args[0]);
			if(!DataDecodeLog.IsInit())
				DataDecodeLog.initLog(config.SearchLog);

			poi_index.engine_version = config.engine_version;
			poi_index.search_version = config.search_version;
			IndexParse parse = new IndexParse();
			
			String xmlFile =config.IndexXMLFile;
			if(args.length>=2){
				xmlFile = args[1];
			}
			
			
			System.out.println(xmlFile);
			HashMap<String, DataIndex> indexs_mo = parse
					.getIndexTable(xmlFile);
			
			
			DataDecodeLog.logger.info("分级开始编译");
			for (DataIndex t : indexs_mo.values()) {
				
				LayIndex index = new LayIndex();
				DomParse aa = new DomParse();
				index.list = aa.GetIndexname(config.m_FileIndex);
				index.InitIndex(index.list, args[0],t);
				
				File indexDir = new File(config.IndexPath + t.getIndex_name());

				// 增加元数据1
				for (IndexTable indext : t.getSource()) {
					if (indext.source_suffix != null&&!indext.source_suffix.equalsIgnoreCase("")) {
						String[] start_end = indext.source_suffix.split(",");
						int start = Integer.parseInt(start_end[0]);
						int end = Integer.parseInt(start_end[1]);
						for (int i = start; i <= end; i++) {
							String file_name = indext.source_path + i;
							poi_index.makeTextIndexByConfig(file_name, null,
									indext, index);
						}
					} else {

						poi_index.makeTextIndexByConfig(indext.source_path,
								null, indext, index);
					}
				}
				index.UnIndex();
			}


			DataDecodeLog.logger.info("分级结束编译");
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
}
