package adminMag;

public class AdminRcd {
	public String m_strName = null;		// 名称
	public String m_strShortenName = null; // 简称
	public String m_strContinentName = null; // 所在洲名称
	public int	  m_iGBCode = 0;		// GB编码
	public double m_dX = 0;				// 定位点X坐标
	public double m_dY = 0;				// 定位点Y坐标
	public int    m_iLevel = 0;			// 地图显示Level
	public int	  m_iWeatherCode;		// 天气码
}