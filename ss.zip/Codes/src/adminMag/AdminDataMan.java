package adminMag;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;



public class AdminDataMan {
	public static final int FULL_NAME_INDEX = 0;	// 全名所在列
	public static final int SHORTEN_NAME_INDEX = 1;	// 简称所在列
	public static final int GB_CODE_INDEX = 2;		// 国标所在列
	public static final int REFERENCE_GB_CODE_INDEX = 3;	// 引用国标所在列
	public static final int COOR_X_INDEX = 4;		// X坐标所在列
	public static final int COOR_Y_INDEX = 5;		// Y坐标所在列
	public static final int SHOW_LEVEL_INDEX = 6;	// 显示级别所在列
	public static final int CONTINENT_INDEX = 7;	// 洲所在列
	public static final int WEATHER_CODE_INDEX = 8;	//天气码所在列
	public static final int USE_COL_COUNT = 9;		// 使用列数
	
	
	public static final int GLOBAL_ADMIN_CODE = 0; // 全球行政区码
	
	public static final int LEVEL_GLOBAL = 0;
	public static final int LEVEL_CONTINENTS = 1;
	public static final int LEVEL_COUNTRY = 2;
	public static final int LEVEL_PROVINCE = 3;
	public static final int LEVEL_CITY = 4;
	public static final int LEVEL_COUNTY = 5;
	
	public static final int ADMIN_RELATIONSHIP_1CONTAIN2 = 1;
	public static final int ADMIN_RELATIONSHIP_2CONTAIN1 = 2;
	public static final int ADMIN_RELATIONSHIP_SAME = 3;
	public static final int ADMIN_RELATIONSHIP_NOT_CONTAIN = 4;
	
	public static final int WORLD_ADMIN_CODE_VALUE_MIN = 900000; // 世界行政区国标最小值
	public static final int CHINA_GB = 990239;			// 中国国标
	public static final int ADMIN_CODE_MAX = 999999;	// 行政区码最大值
	
	public static final int VIRTUAL_ISLAND_LAST_4 = 9900; // 虚拟岛屿行政区码后四位
	public static final int ISLAND_LOCATION_FIRST_4 = 9999; // 岛屿定位行政区码前4位
	
	protected static AdminDataMan m_instance = null;
	protected HashMap<Integer, AdminRcd>  m_mapGBCode2Rcd = null;
	
	// 中国省、市分级记录
	protected ArrayList<AdminHierarchicalRecord> m_listChinaProvinceCity = null; 
	
	protected AdminDataMan(){
		
	}
	
	public static AdminDataMan GetInstance(){
		if(m_instance == null){
			m_instance = new AdminDataMan();
		}
		return m_instance;
	}
	
	/**
	 * 打开行政区数据
	 * @param strAdminDataFile
	 * @return
	 * @note 要求行政区数据文件中，各个记录按照国标码升序排列
	 */
	public boolean OpenAdminDataMan(String strAdminDataFile ){
		m_mapGBCode2Rcd = new HashMap<Integer, AdminRcd>();
		m_listChinaProvinceCity = new ArrayList<AdminHierarchicalRecord>();
		
		try {
			// 加载行政区数据
			FileInputStream is = new FileInputStream(strAdminDataFile);
			InputStreamReader sr = new InputStreamReader(is, "GBK");
			BufferedReader reader = new BufferedReader(sr);
			// 读取记录
			String strLine = null;
			
			while((strLine = reader.readLine()) != null){			
				AdminRcd rcd = new AdminRcd();
				String[] arrItem = strLine.split(",");
				if(arrItem.length != USE_COL_COUNT){
					SearchLog.logger.error("行政区数据中有列数不为" + USE_COL_COUNT + "列的记录，内容：" + strLine);
					SearchLog.logger.error("行政区数据加载失败");
					m_mapGBCode2Rcd = null;
					m_listChinaProvinceCity = null;
					return false;
				}
				rcd.m_strName = arrItem[FULL_NAME_INDEX];
				rcd.m_strShortenName = arrItem[SHORTEN_NAME_INDEX];
				rcd.m_iGBCode = Integer.parseInt(arrItem[GB_CODE_INDEX]);
				rcd.m_dX = Double.parseDouble(arrItem[COOR_X_INDEX]);
				rcd.m_dY = Double.parseDouble(arrItem[COOR_Y_INDEX]);
				rcd.m_iLevel = Integer.parseInt(arrItem[SHOW_LEVEL_INDEX]);
				rcd.m_strContinentName = arrItem[CONTINENT_INDEX];
				rcd.m_iWeatherCode = Integer.parseInt(arrItem[WEATHER_CODE_INDEX]);
				
				
				// 加入hash表
				m_mapGBCode2Rcd.put(Integer.valueOf(rcd.m_iGBCode), rcd);
				
				if(rcd.m_iGBCode < WORLD_ADMIN_CODE_VALUE_MIN && !arrItem[REFERENCE_GB_CODE_INDEX].equalsIgnoreCase("0")){
					// 加入中国行政区分级表
					AddAdminRcdToHierarchicalList(rcd, Integer.parseInt(arrItem[REFERENCE_GB_CODE_INDEX]));
				}
			}
			reader.close();
			sr.close();
			is.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			SearchLog.logger.error("打开行政区数据文件异常");
			
			m_mapGBCode2Rcd = null;
			m_listChinaProvinceCity = null;
			return false;
		}catch(IOException e){
			e.printStackTrace();
			SearchLog.logger.error("读取行政区数据文件异常");
			
			m_mapGBCode2Rcd = null;
			m_listChinaProvinceCity = null;
			return false;
		}catch(Exception e){
			e.printStackTrace();
			SearchLog.logger.error("行政区码转换为整数异常");
			
			m_mapGBCode2Rcd = null;
			m_listChinaProvinceCity = null;
			return false;
		}
		
		return true;		
	}
	
	/**
	 * 关闭行政区数据
	 * @return
	 */
	public void CloseAdminDataMan(){		
		
		if(m_mapGBCode2Rcd != null){
			m_mapGBCode2Rcd.clear();
			m_mapGBCode2Rcd = null;
		}
	}
	
	/**
	 * 行政区数据管理类是否打开
	 * @return
	 */
	public boolean IsAdminDataManOpen(){
		return ( m_mapGBCode2Rcd != null );
	}
	
	/**
	 * 得到中国省、市分级列表
	 * @return 省市分级列表
	 */
	public final ArrayList<AdminHierarchicalRecord> GetChinaProvinceCityHierarchicalList(){
		if( m_mapGBCode2Rcd == null ){
			return null;
		}
		
		return  m_listChinaProvinceCity;
	}	
	
	public final AdminRcd GetAdminRcdFromGBCode(int iGBCode){
		if( m_mapGBCode2Rcd == null ){
			return null;
		}
				
		return  m_mapGBCode2Rcd.get(Integer.valueOf(iGBCode));
	}
	
	/**
	 * 得到国标码对应的行政区名称
	 * @param iCode 行政区码
	 * @return 成功返回名称，否则返回null
	 */
	public String GetAdminNameFromGBCode(int iGBCode){
		if( m_mapGBCode2Rcd == null ){
			return null;
		}
				
		AdminRcd rcd = m_mapGBCode2Rcd.get(Integer.valueOf(iGBCode));
		if(rcd == null){
			return null;
		}else{
			if(IsForeign(iGBCode) || IsChina(iGBCode))
				return rcd.m_strShortenName;
			else
				return rcd.m_strName;
		}
	}
	
	/**
	 * 得到国标码对应的行政区简称
	 * @param iCode 行政区码
	 * @return 成功返回名称，否则返回null
	 */
	public String GetAdminShortenNameFromGBCode(int iGBCode){
		if( m_mapGBCode2Rcd == null ){
			return null;
		}
				
		AdminRcd rcd = m_mapGBCode2Rcd.get(Integer.valueOf(iGBCode));
		if(rcd == null){
			return null;
		}else{
			return rcd.m_strShortenName;
		}
	}
	
	/**
	 * 得到国标码行政区级别
	 * @param iGBCode	行政区国标码
	 * @return 行政区级别。 3：省 4：市 5：区县
	 */
	public static int GetGBCodeAdminLevel(int iGBCode){
		
		if(iGBCode >= WORLD_ADMIN_CODE_VALUE_MIN){
			return LEVEL_COUNTRY;
		}
		
		// 判断是否为区县
		if( ( iGBCode % 100 ) != 0 ){
			return LEVEL_COUNTY;
		}else{
			iGBCode = iGBCode / 100;
			if( ( iGBCode % 100 ) != 0 ){
				return LEVEL_CITY;
			}else{
				return LEVEL_PROVINCE;
			}
		}
	}	
	
	/**
	 * 判断两个行政区的包含关系
	 * @param iCode1 	行政区码1
	 * @param iCode2	行政区码2
	 * @return 包含返回true, 否则返回false;
	 */
	public static int IsAdminContainByGBCode(int iGBCode1, int iGBCode2){ 
		
		if(iGBCode1 == iGBCode2){
			return ADMIN_RELATIONSHIP_SAME;
		}
		
		int iLevel1 = GetGBCodeAdminLevel(iGBCode1);
		int iLevel2 = GetGBCodeAdminLevel(iGBCode2);
		
		if(iLevel1 == iLevel2){
			return ADMIN_RELATIONSHIP_NOT_CONTAIN;
		}
		
		if( iLevel1 < iLevel2){
			if(iLevel1 == LEVEL_GLOBAL){
				return ADMIN_RELATIONSHIP_1CONTAIN2;
			}else if(iLevel1 == LEVEL_COUNTRY){
				// 由于目前不区分国家，直接返回不包含,但若国家是中国则一定包含
				if(IsChina(iGBCode1))
					return ADMIN_RELATIONSHIP_1CONTAIN2;
				else
					return ADMIN_RELATIONSHIP_NOT_CONTAIN;
			}else if(iLevel1 == LEVEL_PROVINCE){
				if( iGBCode1 ==  GetGBBelongProvinceCode(iGBCode2) )
					return ADMIN_RELATIONSHIP_1CONTAIN2;
			}else if(iLevel1 == LEVEL_CITY){
				if( iGBCode1 ==  GetGBBelongCityCode(iGBCode2))
					return ADMIN_RELATIONSHIP_1CONTAIN2;
			}else {
				return ADMIN_RELATIONSHIP_NOT_CONTAIN;
			}	
		}
		else{
			if(iLevel2 == LEVEL_GLOBAL){
				return ADMIN_RELATIONSHIP_2CONTAIN1;
			}else if(iLevel2 == LEVEL_COUNTRY){
				// 由于目前不区分国家，直接返回不包含,但若国家是中国则一定包含
				if(IsChina(iGBCode2))
					return ADMIN_RELATIONSHIP_2CONTAIN1;
				else
					return ADMIN_RELATIONSHIP_NOT_CONTAIN;
			}else if(iLevel2 == LEVEL_PROVINCE){
				if( iGBCode2 ==  GetGBBelongProvinceCode(iGBCode1) )
					return ADMIN_RELATIONSHIP_2CONTAIN1;
			}else if(iLevel2 == LEVEL_CITY){
				if( iGBCode2 ==  GetGBBelongCityCode(iGBCode1) )
					return ADMIN_RELATIONSHIP_2CONTAIN1;
			}else {
				return ADMIN_RELATIONSHIP_NOT_CONTAIN;
			}
		}
		return ADMIN_RELATIONSHIP_NOT_CONTAIN;
	}
	
	/**
	 * 得到指定国标码所属省编码
	 * @param iGBCode
	 * @return
	 */
	public static int GetGBBelongProvinceCode(int iGBCode ){
		return (iGBCode/10000) * 10000;
	}
	
	/**
	 * 得到指定国标码所属市编码
	 * @param iGBCode
	 * @return
	 */
	public static int GetGBBelongCityCode(int iGBCode ){
		return (iGBCode/100) * 100;
	}
	
	/**
	 * 特殊市级行政区升级
	 * @param iGBCode	行政区码
	 * @return 若为特殊市（直辖市的直辖区县），则将行政区码升级致市级
	 */
	public static int SpecialCityLevelUpgradeByGBCode(int iGBCode){		
		switch(iGBCode){
			case 110100:
			case 110200:
			case 120100:
			case 120200:
			case 310100:
			case 310200:
			case 500100:
			case 500200:
			{
				// 需要升到省级				
				return ( iGBCode / 10000 ) * 10000;				
			}
		}
		
		return iGBCode;
	}
	
	/**
	 * 是否指定行政区码是特殊城市
	 * @param iGBCode
	 * @return
	 */
	public static boolean IsGBCodeSpecialCityLevel(int iGBCode){
		switch(iGBCode){
			case 110100:
			case 110200:
			case 120100:
			case 120200:
			case 310100:
			case 310200:
			case 500100:
			case 500200:
			case 810100:
			case 820100:
			case 710100:
			{
				return true;			
			}		
		}
		return false;
	}
	
	/**
	 *  是否是特殊省级行政区（等同于城市范围的省）
	 * @param iCode
	 * @return 
	 */
	public static boolean IsGBCodeSpecialProvinceLevel(int iGBCode){		
		switch(iGBCode){
			case 110000:
			case 120000:
			case 310000:
			case 500000:
			case 810000:
			case 820000:
			case 710000:
			{
						return true;
			}
		}
		
		return false;
	}
	
	/**
	 * 判断是否是虚拟岛屿
	 * @param iGBCode
	 * @return
	 */
	public static boolean IsVirtualIsland(int iGBCode){
		iGBCode -= iGBCode / 10000 * 10000;
		if( iGBCode == VIRTUAL_ISLAND_LAST_4)
			return true;
		else
			return false;
	}
	
	/**
	 * 是否是直接定位岛屿
	 * @param iGBCode
	 * @return
	 */
	public static boolean IsLocationIsland(int iGBCode){
		iGBCode /= 100;
		if( iGBCode == ISLAND_LOCATION_FIRST_4 )
			return true;
		else
			return false;
	}
	
	/**
	 *  是否是特殊区县级行政区（等同于省级的区县：中沙、南沙、西沙）
	 * @param iCode
	 * @return 
	 */
	public static boolean IsGBCodeSpecialCountyLevel(int iGBCode){
		switch(iGBCode){
		  case 419001:
		  case 429004:
		  case 429005:
		  case 429006:
		  case 429021:
		  case 469001:
		  case 469002:
		  case 469003:
		  case 469005:
		  case 469006:
		  case 469007:
		  case 469021:
		  case 469022:
		  case 469023:
		  case 469024:
		  case 469025:
		  case 469026:
		  case 469027:
		  case 469028:
		  case 469029:
		  case 469030:
		  case 659001:
		  case 659002:
		  case 659003:
		  case 659004:
			{
				return true;
			}
		}
	
		return false;
	}
	
	/**
	 * 是否为中国
	 * @param iGBCode	国标码
	 * @return
	 */
	public static boolean IsChina(int iGBCode){
		return (iGBCode == CHINA_GB);
	}
	
	/**
	 * 是否是外国
	 * @param iGBCode 国标码
	 */
	public static boolean IsForeign(int iGBCode){
		return (iGBCode > WORLD_ADMIN_CODE_VALUE_MIN) && (iGBCode != CHINA_GB);
	}
	
	/**
	 * 是否是全球
	 * @param iGBCode
	 * @return
	 */
	public static boolean IsGlobal(int iGBCode){
		return iGBCode == GLOBAL_ADMIN_CODE;
	}
	
	/**
	 * 指定字符传中是否含有区县级行政区尾词
	 * @param strString
	 * @return 含有返回true, 否则返回false
	 */
	public static boolean IsHaveCountyPostfix(String strString){
		if(strString.indexOf("市") != -1
			|| strString.indexOf("区") != -1
			|| strString.indexOf("县") != -1
			|| strString.indexOf("镇") != -1
			|| strString.indexOf("旗") != -1
			|| strString.indexOf("州") != -1)
			return true;
		else
			return false;			
	}
	
	protected  void AddAdminRcdToHierarchicalList(AdminRcd rcd, int iRefGBCode){
		// 得到参考国标码等级
		int iRefLevel = GetGBCodeAdminLevel(iRefGBCode);
		if(iRefLevel > LEVEL_CITY)
			return;
		
		// 得到行政区等级
		int iLevel = GetGBCodeAdminLevel(rcd.m_iGBCode);
		if(iLevel == LEVEL_PROVINCE){
			// 直接加入到一级省列表
			AdminHierarchicalRecord addRcd = new AdminHierarchicalRecord();
			addRcd.m_strName = rcd.m_strName;
			addRcd.m_iGBCode = rcd.m_iGBCode;
			addRcd.m_iLevel = LEVEL_PROVINCE;
			addRcd.m_listLowerAdmin = new ArrayList<AdminHierarchicalRecord>();
			
			m_listChinaProvinceCity.add(addRcd);
		}else { // 此时可能是地级市，也可能时省直辖县
			// 找到所属的省
			int iProvinceCode = GetGBBelongProvinceCode(rcd.m_iGBCode);
			int iProvinceCount = m_listChinaProvinceCity.size();
			int i = 0;
			for(; i < iProvinceCount; i++){
				if(m_listChinaProvinceCity.get(i).m_iGBCode == iProvinceCode)
					break;
			}		
			
			// 若没有找到对应的省
			if(i == iProvinceCount){
				SearchLog.logger.error("无法加载生成全国省市分级列表, 找不到所在省记录：" + rcd.m_iGBCode);
				return;
			}
			
			// 添加一条记录
			AdminHierarchicalRecord addRcd = new AdminHierarchicalRecord();
			addRcd.m_strName = rcd.m_strName;
			addRcd.m_iGBCode = rcd.m_iGBCode;
			addRcd.m_iLevel = LEVEL_CITY;
			addRcd.m_listLowerAdmin = null;			
			
			m_listChinaProvinceCity.get(i).m_listLowerAdmin.add(addRcd);			
		}
	}
}


