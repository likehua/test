package adminMag;

import java.util.ArrayList;

/**
 * 行政区分级记录
 * @author jiangjiang
 *
 */
public class AdminHierarchicalRecord {
	public String	m_strName = null;	// 名称
	public int 	m_iGBCode = 0;	// 国标码
	public int 	m_iLevel = 0;	// 行政区等级	
	public ArrayList<AdminHierarchicalRecord> m_listLowerAdmin = null;
}
