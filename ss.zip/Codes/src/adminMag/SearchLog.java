package adminMag;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class SearchLog {
	
	public static Logger logger = null ;
	public static Logger SearchLog = null;
	public static Logger SuggestLog = null;
	
	protected static boolean bIsInit = false;
	
	public static void initLog(String strCfgPath){
		if(bIsInit)
			return;
//		
//		PropertyConfigurator.configure(Configution.IniPath
//				+ Configution.SearchLog);
		logger = Logger.getLogger( SearchLog.class.getName ());
	
		
		bIsInit = true;
	}	
	
	public static boolean IsInit(){
		return bIsInit;
	}
}
