package maketext;

import index.ConfigParse;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;

import log.DataDecodeLog;

public class ImportText {

	public static HashMap<Integer, FileOutputStream> outstream_map = new HashMap<Integer, FileOutputStream>();
	public static HashMap<Integer, Writer> writer_map = new HashMap<Integer, Writer>();

	/**
	 * 关闭打开的文件和流
	 * 
	 * @return
	 */
	public static boolean CloseOutAndWriter() {

		for (Writer writer : writer_map.values()) {
			try {
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		for (FileOutputStream file_out : outstream_map.values()) {
			try {
				file_out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return false;

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		// FileOutputStream out = null;
		// FileOutputStream outSTr = null;
		// BufferedOutputStream Buff = null;
		// FileWriter fw = null;

		Date begin_curr = new Date();
		System.out.println(begin_curr.toString());
		int count = 0;// 鍐欐枃浠惰鏁�
		int num = 1;

		// FileOutputStream out = null;

		ConfigParse config = new ConfigParse();
		config.ParseConfig(args[0]);
		//if(!DataDecodeLog.IsInit())
			//DataDecodeLog.initLog(config.SearchLog);
		//导出地标文件
		//ExpertLandMark(config.m_Landmark);
		ImportLandmark land = new ImportLandmark();
		//导出地标文件
		land.ExpertLandMark(config.m_Landmark);
		String poiSql = config.m_poiSql;
		if(poiSql==null||poiSql.equals("")){
			poiSql="SELECT * FROM POIBASEINFO  where auditingstate = '0' ";
		}
		//DataDecodeLog.logger.info("oracle sql:"+poiSql);
		System.out.println("oracle sql:"+poiSql);
		FileOutputStream fos = null;
		Writer out = null;

		try {
			// fw = new FileWriter("aaaa", false);
			int length = 0;
			// for (int l = 1; l < 45; l++) {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("aaa1");
								Connection conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@192.168.1.128:1521:tianditu128", "tianditu",
					"tianditupoi");
			System.out.println("aaa12");
			Statement stmt = conn.createStatement();
			System.out.println("aaa11");
			System.out.println("commit sql:"+poiSql);
			ResultSet rs = stmt
					.executeQuery(poiSql);// where
			// nid
			// >
			// 10007551506
			// System.out.println(l+" aaaa");

			while (rs.next()) {

				String name = rs.getString("NAME");
				String fushu = rs.getString("NAMEDESCRIPTION");
				String oname = rs.getString("OTHERNAME");
				String oldname = rs.getString("OLDNAME");
				String jianname = rs.getString("ABBREVIATION");
				// 增加英文版数据
				String eng_name = rs.getNString("ENGLISHNAME");

				if (fushu != null) {
					// System.out.println(fushu);
					name += "(";
					name += fushu;
					name += ")";
					// System.out.println(name);
				} else
					;
				// if(name.length() > length)
				// {
				// length = name.length();
				// continue;
				// }
				// if (name.length() == l) {
				count++;
				long id = rs.getLong("NID");
				// String result = id + "####";

				name += "***";
				name += oname;
				name += "***";
				name += oldname;
				name += "***";
				name += jianname;

				name = name.replace("null", "");
				name = name.trim();

				// result += name;
				String result = "####";

				String address = rs.getString("ADDRESS");
				result += address;
				result += "####";
				String tel = rs.getString("TELEPHONE");
				result += tel;
				result += "####";
				String citycode = rs.getString("CITYCODENEW");
				result += citycode;
				result += "####";

				String type = rs.getString("TYPE");
				result += type;
				result += "####";

				double lon = rs.getDouble("DISPLAY_X");
				long ilon = (int) (lon * 1000000);
				result += lon;
				result += "####";
				double lat = rs.getDouble("DISPLAY_Y");
				long ilat = (int) (lat * 1000000);
				result += lat;
				result += "####";
				String importance = rs.getString("IMPORTANCE");
				result += importance;
				result += "####";
				// 品牌词
				String brand = rs.getString("BRAND");
				result += brand;
				result += "####";
				// 准确性
				String acc = rs.getString("ACCURACY");
				result += acc;
				result += "####";
				// 附属行政区划代码
				String val = rs.getString("VANITYCITY");
				result += val;
				result += "####";
				String poitag = rs.getString("TAG");
				result += poitag;
				result += "####";
				String url = rs.getString("URL");
				String user = rs.getString("USERS");
				
				String alternate_type = rs.getString("OTHERTYPE");
				
				if (user != null && user.startsWith("@")) {
					result += url;
				}else if(type.equalsIgnoreCase("090203")||type.equalsIgnoreCase("090204")||(alternate_type!=null &&(alternate_type.contains("090203")||alternate_type.contains("090204")))){
					result += url;
				}


				result += "####";
				// 增加备用类
				
				result += alternate_type;
				result += "####";
				
				
				// 增加标签
				String tag = rs.getString("TAG");
				result += tag;
				result += "####";
				
				// 增加标签
				String dianping_id = "";
				String sdleisure_id = rs.getString("sdleisure_id");
				String sddining_id = rs.getString("sddining_id");
				String sdhotel_id = rs.getString("sdhotel_id");
				if(sdleisure_id!=null&&!sdleisure_id.equals("null")){
					dianping_id=sdleisure_id;
				}else if(sdhotel_id!=null&&!sdhotel_id.equals("null")){
					dianping_id=sdhotel_id;
				}else {
					dianping_id=sddining_id;		
				}
				result += dianping_id;
				result += "####";
				// System.out.println(result);
				result += "\n";
				num++;
				// 增加文件描述符打开
				String zn_result = id + "####" + name + result;
				String en_result = null;
				// 中文倒库
				out = writer_map.get(name.length());
				if (out == null) {
					fos = new FileOutputStream(config.m_IndexSource
							+ name.length());
					outstream_map.put(name.length(), fos);
					out = new OutputStreamWriter(fos, "UTF-8");
					writer_map.put(name.length(), out);
				}

				out.write(zn_result);
				// 英文倒库
				// System.out.println(eng_name+":"+citycode);

				if (eng_name != null && !eng_name.equalsIgnoreCase("null")
						&& citycode.startsWith("99")) {
					eng_name += "*********";
					en_result = id + "####" + eng_name + result;
					// System.out.println(en_result);
					out = writer_map.get(eng_name.length());
					if (out == null) {
						fos = new FileOutputStream(config.m_IndexSource
								+ eng_name.length());
						outstream_map.put(eng_name.length(), fos);
						out = new OutputStreamWriter(fos, "UTF-8");
						writer_map.put(eng_name.length(), out);
					}
					out.write(en_result);
				}

				if (count % 50000 == 0) {
					System.out.println(count);

				}
				// }

				if (num % 10000 == 0) {
					// System.out.println(num);
					// fw.flush();
					out.flush();
					// fw.close();
					// return;
				}

				// out.write(result.getBytes());

			}
			System.out.println(count + "  " + num);
			// System.out.println(count+"length "+length);
			conn.close();
			// }

			// fw.close();
			CloseOutAndWriter();
			Date curr = new Date();
			System.out.println(curr.toString());
			// out.close();
			// fos.close();
			// out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
