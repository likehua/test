package maketext;

import index.ConfigParse;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ImportLandmarkEX {
	
	private ConfigParse config;
	/**
	 * 导出地标数据
	 */
	public void ExpertLandMark(String filename) {
		
		//DataDecodeLog.logger.info("ExpertLandMark"+filename);
		FileOutputStream fos = null;
		Writer out = null;
		try {
			fos = new FileOutputStream(filename);
			out = new OutputStreamWriter(fos, "UTF-8");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int count = 0;
		try {
			// fw = new FileWriter("aaaa", false);
			int length = 0;
			// for (int l = 1; l < 45; l++) {
			
			//final String MYSQL_DRIVER_CLASS = "com.mysql.jdbc.Driver";
			//final String URL = "jdbc:mysql://10.2.31.182:3306/tdt_poi?useUnicode=true&charaterEncoding=UTF-8&user=poi&password=poi123";
			Class.forName(config.DRIVER_CLASS);
			
			Connection conn = DriverManager.getConnection(config.JDBC_URL,config.JDBC_USER,config.JDBC_PASSWORD);
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt
					.executeQuery("select * from poibaseinfo t where t.importance='9' and t.auditingstate='0' ");// where

			while (rs.next()) {

				String name = rs.getString(2);
				String fushu = rs.getString(9);
				String oname = rs.getString(4);
				String oldname = rs.getString(6);
				String jianname = rs.getString(37);
				//显示级别
				String display = rs.getString(45);
				// 增加英文版数据
				String eng_name = rs.getString(8);

				if (fushu != null) {
					// System.out.println(fushu);
					name += "(";
					name += fushu;
					name += ")";
					// System.out.println(name);
				} else
					;
				// if(name.length() > length)
				// {
				// length = name.length();
				// continue;
				// }
				// if (name.length() == l) {
				count++;
				long id = rs.getLong(1);
				// String result = id + "####";

				name += "***";
				name += oname;
				name += "***";
				name += oldname;
				name += "***";
				name += jianname;

				name = name.replace("null", "");
				name = name.trim();

				// result += name;
				String result = "####";

				String address = rs.getString(10);
				result += address;
				result += "####";
				String tel = rs.getString(11);
				result += tel;
				result += "####";
				String citycode = rs.getString(48);
				result += citycode;
				result += "####";

				String type = rs.getString(15);
				result += type;
				result += "####";

				double lon = rs.getDouble(17);
				long ilon = (int) (lon * 1000000);
				result += lon;
				result += "####";
				double lat = rs.getDouble(18);
				long ilat = (int) (lat * 1000000);
				result += lat;
				result += "####";
				String importance = rs.getString(28);
				result += importance;
				result += "####";
				// 品牌词
				String tag = rs.getString(34);
				result += tag;
				result += "####";
				// 准确性
				String acc = rs.getString(27);
				result += acc;
				result += "####";
				// 附属行政区划代码
				String val = rs.getString(33);
				result += val;
				result += "####";
				String poitag = rs.getString(29);
				result += poitag;
				result += "####";
				String url = rs.getString(23);
				String user = rs.getString(30);
				if (user != null && user.startsWith("@")) {
					result += url;
				}

				result += "####";
				// 增加备用类
				String alternate_type = rs.getString(16);
				result += alternate_type;
				result += "####";
				//增加显示级别
				result += display;
				result += "####";
				
				// System.out.println(result);
				result += "\n";
				// 增加文件描述符打开
				String zn_result = id + "####" + name + result;
				String en_result = null;
				// 中文倒库
				out.write(zn_result);

			}
			conn.close();
			out.close();
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final String configPath = "c:\\poi\\config.txt";
		ConfigParse config = new ConfigParse();
		//config.ParseConfig(configPath);
		config.ParseConfig(args[0]);
		//if(!DataDecodeLog.IsInit())
			//DataDecodeLog.initLog(config.SearchLog);
		
		ImportLandmarkEX land = new ImportLandmarkEX();
		//导出地标文件
		land.ExpertLandMark(config.m_Landmark);

	}


	public ConfigParse getConfig() {
		return config;
	}


	public void setConfig(ConfigParse config) {
		this.config = config;
	}
}
